<?php
/*
Plugin Name: Barow - Sistema de Reservas para Restaurantes
Description: Sistema completo de gestión de reservas para restaurantes y bares. Permite a los clientes hacer reservas online, envía notificaciones por email automáticamente y proporciona un panel de administración completo con analytics, gestión de clientes y herramientas de exportación.
Version: 2.0.0
Author: Sebastián Gonzalez
Author URI: https://www.jsebastiangonzalez.com/
Plugin URI: https://github.com/sebastiangrl/barow
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: barow
Domain Path: /languages
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Network: false
*/

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Definir constantes
define('BAROW_VERSION', '2.0.0');
define('BAROW_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BAROW_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Clase principal de Barow - Versión corregida y limpia
 */
class Barow_Simple {
    
    private static $instance = null;
    
    /**
     * Singleton pattern
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
    }
    
    /**
     * Inicializar hooks
     */
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('init', array($this, 'init_shortcodes'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'add_settings_link'));
    }
    
    /**
     * Activación del plugin
     */
    public function activate() {
        $this->create_database_table();
        $this->add_capabilities();
        flush_rewrite_rules();
    }
    
    /**
     * Crear tabla de base de datos
     */
    private function create_database_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'reservas';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            nombre_cliente tinytext NOT NULL,
            email_cliente varchar(100) NOT NULL,
            telefono_cliente varchar(15) NOT NULL,
            fecha_reserva date NOT NULL,
            hora_reserva time NOT NULL,
            cantidad_personas int(2) NOT NULL,
            estado varchar(20) DEFAULT 'activa',
            fecha_creacion datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Agregar capacidades de usuario
     */
    private function add_capabilities() {
        $admin_role = get_role('administrator');
        if ($admin_role) {
            $admin_role->add_cap('manage_reservas');
        }
    }
    
    /**
     * Scripts del admin
     */
    public function admin_enqueue_scripts($hook) {
        if (strpos($hook, 'reserva-mesas') !== false || strpos($hook, 'barow-') !== false) {
            wp_enqueue_style('dashicons');
            wp_enqueue_style('barow-admin', BAROW_PLUGIN_URL . 'assets/css/admin.css', array(), BAROW_VERSION . '-' . time());
            wp_enqueue_script('jquery');
        }
    }
    
    /**
     * Agregar enlace de ajustes en la página de plugins
     */
    public function add_settings_link($links) {
        $settings_link = '<a href="' . admin_url('admin.php?page=barow-ajustes') . '">' . __('Ajustes', 'barow') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
    
    /**
     * Menú de administración
     */
    public function admin_menu() {
        // Menú principal - apunta directamente a Todas las Reservas
        add_menu_page(
            __('Gestión de Reservas', 'barow'),
            __('Reservas', 'barow'),
            'manage_reservas',
            'reserva-mesas',
            array($this, 'mostrar_todas_reservas'),
            'dashicons-calendar',
            6
        );
        
        // Primera pestaña: Todas las Reservas (página principal)
        add_submenu_page(
            'reserva-mesas',
            __('Todas las Reservas', 'barow'),
            __('Todas las Reservas', 'barow'),
            'manage_reservas',
            'reserva-mesas',
            array($this, 'mostrar_todas_reservas')
        );
        
        // Segunda pestaña: Clientes
        add_submenu_page(
            'reserva-mesas',
            __('Clientes', 'barow'),
            __('Clientes', 'barow'),
            'manage_reservas',
            'barow-clientes',
            array($this, 'mostrar_clientes')
        );
        
        // Tercera pestaña: Analytics
        add_submenu_page(
            'reserva-mesas',
            __('Analytics', 'barow'),
            __('Analytics', 'barow'),
            'manage_reservas',
            'barow-analytics',
            array($this, 'mostrar_analytics')
        );
        
        // Cuarta pestaña: Ajustes
        add_submenu_page(
            'reserva-mesas',
            __('Ajustes', 'barow'),
            __('Ajustes', 'barow'),
            'manage_reservas',
            'barow-ajustes',
            array($this, 'mostrar_ajustes')
        );
        
        // Quinta pestaña: Personalización
        add_submenu_page(
            'reserva-mesas',
            __('Personalización', 'barow'),
            __('Personalización', 'barow'),
            'manage_reservas',
            'barow-personalizacion',
            array($this, 'mostrar_personalizacion')
        );
    }
    
    /**
     * Mostrar clientes
     */
    public function mostrar_clientes() {
        $clientes_file = BAROW_PLUGIN_DIR . 'admin/views/clientes.php';
        if (file_exists($clientes_file)) {
            include $clientes_file;
        } else {
            echo '<div class="wrap"><h1><span class="dashicons dashicons-groups"></span> Clientes</h1><p>Vista de clientes no disponible.</p></div>';
        }
    }
    
    /**
     * Mostrar analytics
     */
    public function mostrar_analytics() {
        $analytics_file = BAROW_PLUGIN_DIR . 'admin/views/analytics.php';
        if (file_exists($analytics_file)) {
            include $analytics_file;
        } else {
            echo '<div class="wrap"><h1><span class="dashicons dashicons-chart-area"></span> Analytics</h1><p>Vista de analytics no disponible.</p></div>';
        }
    }
    
    /**
     * Mostrar todas las reservas
     */
    public function mostrar_todas_reservas() {
        $reservas_file = BAROW_PLUGIN_DIR . 'admin/views/todas-reservas.php';
        if (file_exists($reservas_file)) {
            include $reservas_file;
        } else {
            echo '<div class="wrap"><h1><span class="dashicons dashicons-list-view"></span> Todas las Reservas</h1><p>Vista de reservas no disponible.</p></div>';
        }
    }
    
    /**
     * Mostrar ajustes
     */
    public function mostrar_ajustes() {
        $ajustes_file = BAROW_PLUGIN_DIR . 'admin/views/ajustes.php';
        if (file_exists($ajustes_file)) {
            include $ajustes_file;
            // Llamar a la función que muestra la página de ajustes
            if (function_exists('reserva_mesas_pagina_ajustes')) {
                reserva_mesas_pagina_ajustes();
            }
        } else {
            echo '<div class="wrap"><h1><span class="dashicons dashicons-admin-settings"></span> Ajustes</h1><p>Vista de ajustes no disponible.</p></div>';
        }
    }
    
    /**
     * Mostrar personalización
     */
    public function mostrar_personalizacion() {
        $personalizacion_file = BAROW_PLUGIN_DIR . 'admin/views/personalizacion.php';
        if (file_exists($personalizacion_file)) {
            include $personalizacion_file;
        } else {
            echo '<div class="wrap"><h1><span class="dashicons dashicons-admin-appearance"></span> Personalización</h1><p>Vista de personalización no disponible.</p></div>';
        }
    }
    
    /**
     * Inicializar shortcodes
     */
    public function init_shortcodes() {
        add_shortcode('barow_formulario', array($this, 'shortcode_formulario'));
    }
    
    /**
     * Shortcode del formulario
     */
    public function shortcode_formulario($atts = array()) {
        // Cargar estilos y scripts del frontend para el formulario
        wp_enqueue_style('barow-frontend', BAROW_PLUGIN_URL . 'assets/css/frontend.css', array(), BAROW_VERSION);
        
        // Cargar Flatpickr para el selector de fechas
        wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css', array(), '4.6.9');
        wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr', array(), '4.6.9', true);
        wp_enqueue_script('flatpickr-es', 'https://npmcdn.com/flatpickr/dist/l10n/es.js', array('flatpickr'), '4.6.9', true);
        
        // Cargar intl-tel-input para el selector de países
        wp_enqueue_style('intl-tel-input', 'https://cdn.jsdelivr.net/npm/intl-tel-input@18.1.1/build/css/intlTelInput.css', array(), '18.1.1');
        wp_enqueue_script('intl-tel-input', 'https://cdn.jsdelivr.net/npm/intl-tel-input@18.1.1/build/js/intlTelInput.min.js', array('jquery'), '18.1.1', true);
        
        // Incluir las funciones necesarias
        if (!function_exists('reserva_mesas_formulario_shortcode')) {
            $form_file = BAROW_PLUGIN_DIR . 'includes/form-reservas.php';
            if (file_exists($form_file)) {
                require_once $form_file;
            }
        }
        
        if (!function_exists('enviar_notificacion_cliente')) {
            $notif_file = BAROW_PLUGIN_DIR . 'includes/notificaciones.php';
            if (file_exists($notif_file)) {
                require_once $notif_file;
            }
        }
        
        // Ejecutar la función del formulario
        if (function_exists('reserva_mesas_formulario_shortcode')) {
            return reserva_mesas_formulario_shortcode($atts);
        } else {
            return '<div class="barow-error">Formulario de reservas no disponible.</div>';
        }
    }
}

/**
 * Función de inicialización
 */
function barow_init() {
    return Barow_Simple::get_instance();
}

// Activar el plugin
add_action('plugins_loaded', 'barow_init');

// Funciones de compatibilidad
function reserva_mesas_activar() {
    $barow = barow_init();
    $barow->activate();
}

// Mantener compatibilidad con el procesamiento AJAX existente
add_action('wp_ajax_procesar_reserva', 'barow_procesar_reserva_ajax');
add_action('wp_ajax_nopriv_procesar_reserva', 'barow_procesar_reserva_ajax');

function barow_procesar_reserva_ajax() {
    // Verificar nonce
    if (!wp_verify_nonce($_POST['nonce'], 'reserva_nonce')) {
        wp_die('Acceso no autorizado');
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'reservas';
    
    $nombre = sanitize_text_field($_POST['nombre_cliente']);
    $email = sanitize_email($_POST['email_cliente']);
    $telefono = sanitize_text_field($_POST['telefono_cliente']);
    $fecha = sanitize_text_field($_POST['fecha_reserva']);
    $hora = sanitize_text_field($_POST['hora_reserva']);
    $personas = intval($_POST['cantidad_personas']);
    
    // Verificar duplicados básico
    $duplicado = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name 
        WHERE email_cliente = %s 
        AND fecha_reserva = %s 
        AND estado != 'cancelada'",
        $email, $fecha
    ));
    
    if ($duplicado > 0) {
        wp_send_json_error(array('mensaje' => 'Ya tienes una reserva para esta fecha'));
        return;
    }
    
    // Insertar reserva
    $resultado = $wpdb->insert(
        $table_name,
        array(
            'nombre_cliente' => $nombre,
            'email_cliente' => $email,
            'telefono_cliente' => $telefono,
            'fecha_reserva' => $fecha,
            'hora_reserva' => $hora,
            'cantidad_personas' => $personas,
            'estado' => 'activa'
        )
    );
    
    if ($resultado) {
        // Enviar notificación si existe el archivo
        if (file_exists(BAROW_PLUGIN_DIR . 'includes/notificaciones.php')) {
            include_once BAROW_PLUGIN_DIR . 'includes/notificaciones.php';
            if (function_exists('enviar_notificacion_reserva')) {
                enviar_notificacion_reserva($wpdb->insert_id);
            }
        }
        
        wp_send_json_success(array('mensaje' => 'Reserva creada exitosamente', 'id' => $wpdb->insert_id));
    } else {
        wp_send_json_error(array('mensaje' => 'Error al crear la reserva'));
    }
}
