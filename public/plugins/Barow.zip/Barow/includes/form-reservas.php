<?php
//---------------------------------------------FORMULARIO DE RESERVAR-------------------------------------------------------------------------------------

function reserva_mesas_formulario_shortcode()
{
    // Obtener configuración de personalización
    $personalizacion = get_option('barow_personalizacion', array());
    
    // Valores con compatibilidad
    $borde_color = !empty($personalizacion['borde_color']) ? $personalizacion['borde_color'] : get_option('reserva_mesas_borde_color', '#3498db');
    $bg_color = !empty($personalizacion['bg_color']) ? $personalizacion['bg_color'] : get_option('reserva_mesas_bg_color', '#3498db');
    $btn_font_color = !empty($personalizacion['btn_font_color']) ? $personalizacion['btn_font_color'] : get_option('reserva_mesas_btn_font_color', '#ffffff');
    $label_font_color = !empty($personalizacion['label_font_color']) ? $personalizacion['label_font_color'] : get_option('reserva_mesas_label_font_color', '#333333');
    $borde_radius = !empty($personalizacion['borde_radius']) ? $personalizacion['borde_radius'] : get_option('reserva_mesas_borde_radius', '5');
    $input_bg_color = !empty($personalizacion['input_bg_color']) ? $personalizacion['input_bg_color'] : '#ffffff';
    $input_text_color = !empty($personalizacion['input_text_color']) ? $personalizacion['input_text_color'] : '#333333';
    $form_bg_color = !empty($personalizacion['form_bg_color']) ? $personalizacion['form_bg_color'] : '#ffffff';
    $titulo_formulario = !empty($personalizacion['titulo_formulario']) ? $personalizacion['titulo_formulario'] : 'Reserva tu Mesa';
    $texto_boton = !empty($personalizacion['texto_boton']) ? $personalizacion['texto_boton'] : 'Reservar Ahora';

    // Obtener el máximo de personas permitido desde los ajustes
    $max_personas = get_option('reserva_mesas_max_personas', 10);
    $hora_inicio = get_option('reserva_mesas_hora_inicio', '17:00');
    $hora_fin = get_option('reserva_mesas_hora_fin', '23:00');

    // Obtener días bloqueados y días cerrados desde los ajustes
    $dias_bloqueados = get_option('reserva_mesas_dias_bloqueados', []); 
    $dias_cerrados = get_option('reserva_mesas_dias_cerrados', []); 
    $dias_bloqueados_json = json_encode($dias_bloqueados);
    $dias_cerrados_json = json_encode($dias_cerrados);

    // Generar horas disponibles para restaurante
    $horas_disponibles = [];
    $hora_actual = strtotime($hora_inicio);
    $hora_fin_time = strtotime($hora_fin);

    while ($hora_actual <= $hora_fin_time) {
        $horas_disponibles[] = date('H:i', $hora_actual);
        $hora_actual = strtotime('+15 minutes', $hora_actual);
    }

    // Llamar a la función para guardar las reservas y obtener el feedback
    $feedback = reserva_mesas_guardar_reserva();

    ob_start();
    ?>
    <style>
    .reserva-form {
        background: <?php echo esc_attr($form_bg_color); ?>;
        border: 2px solid <?php echo esc_attr($borde_color); ?>;
        border-radius: <?php echo intval($borde_radius); ?>px;
        padding: 30px;
        max-width: 500px;
        margin: 0 auto;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    
    .reserva-form h2, .reserva-form h3 {
        color: <?php echo esc_attr($label_font_color); ?>;
        text-align: center;
        margin-bottom: 25px;
        font-size: 24px;
        font-weight: 600;
    }
    
    .reserva-form .CamposLabel {
        color: <?php echo esc_attr($label_font_color); ?> !important;
        font-weight: 600;
        display: block;
        margin-bottom: 10px;
        font-size: 15px;
        line-height: 1.4;
    }
    
    .reserva-form .bordesCampos {
        background: <?php echo esc_attr($input_bg_color); ?> !important;
        color: <?php echo esc_attr($input_text_color); ?> !important;
        border: 2px solid <?php echo esc_attr($borde_color); ?> !important;
        border-radius: <?php echo intval($borde_radius); ?>px !important;
        padding: 16px 20px;
        width: 100%;
        font-size: 16px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
        box-sizing: border-box;
        min-height: 50px;
    }
    
    .reserva-form .bordesCampos:focus {
        border-color: <?php echo esc_attr($bg_color); ?> !important;
        box-shadow: 0 0 0 3px <?php echo esc_attr($bg_color); ?>33 !important;
        outline: none;
    }
    
    .reserva-form button[type="submit"] {
        background: <?php echo esc_attr($bg_color); ?> !important;
        color: <?php echo esc_attr($btn_font_color); ?> !important;
        border: none;
        border-radius: <?php echo intval($borde_radius); ?>px;
        padding: 18px 30px;
        font-size: 16px;
        font-weight: 600;
        width: 100%;
        cursor: pointer;
        transition: all 0.3s ease;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-top: 20px;
        min-height: 56px;
    }
    
    .reserva-form button[type="submit"]:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        filter: brightness(1.1);
    }
    
    /* Estilos para el selector de teléfono internacional */
    .reserva-form .phone-group {
        position: relative;
        margin-bottom: 15px;
        width: 100% !important;
    }
    
    .reserva-form .iti {
        width: 100% !important;
        margin-bottom: 0 !important;
        display: block !important;
        position: relative !important;
    }
    
    .reserva-form .iti__country-list {
        border-radius: <?php echo intval($borde_radius); ?>px !important;
        border: 2px solid <?php echo esc_attr($borde_color); ?> !important;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
        z-index: 1050 !important;
    }
    
    .reserva-form .iti__flag-container {
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        height: 100% !important;
        z-index: 10 !important;
    }
    
    .reserva-form .iti__selected-flag {
        background: <?php echo esc_attr($input_bg_color); ?> !important;
        border: 2px solid <?php echo esc_attr($borde_color); ?> !important;
        border-right: none !important;
        border-radius: <?php echo intval($borde_radius); ?>px 0 0 <?php echo intval($borde_radius); ?>px !important;
        padding: 0 12px !important;
        min-height: 50px !important;
        max-height: 50px !important;
        height: 50px !important;
        box-sizing: border-box !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        width: 80px !important;
        min-width: 80px !important;
        max-width: 80px !important;
        position: relative !important;
    }
    
    .reserva-form .iti__selected-flag:hover,
    .reserva-form .iti__selected-flag:focus {
        border-color: <?php echo esc_attr($bg_color); ?> !important;
        box-shadow: 0 0 0 3px <?php echo esc_attr($bg_color); ?>33 !important;
    }
    
    .reserva-form .iti__arrow {
        margin-left: 6px !important;
        border: none !important;
        width: 0 !important;
        height: 0 !important;
        border-left: 4px solid transparent !important;
        border-right: 4px solid transparent !important;
        border-top: 4px solid #666 !important;
    }
    
    .reserva-form .iti input[type="tel"] {
        background: <?php echo esc_attr($input_bg_color); ?> !important;
        color: <?php echo esc_attr($input_text_color); ?> !important;
        border: 2px solid <?php echo esc_attr($borde_color); ?> !important;
        border-radius: 0 <?php echo intval($borde_radius); ?>px <?php echo intval($borde_radius); ?>px 0 !important;
        border-left: none !important;
        margin-bottom: 0 !important;
        padding: 16px 20px 16px 92px !important;
        font-size: 16px !important;
        min-height: 50px !important;
        max-height: 50px !important;
        height: 50px !important;
        box-sizing: border-box !important;
        width: 100% !important;
        transition: all 0.3s ease !important;
    }
    
    .reserva-form .iti input[type="tel"]:focus {
        border-color: <?php echo esc_attr($bg_color); ?> !important;
        box-shadow: 0 0 0 3px <?php echo esc_attr($bg_color); ?>33 !important;
        outline: none !important;
    }
    
    .reserva-form .form-group {
        display: flex;
        gap: 15px;
        margin-bottom: 15px;
    }
    
    .reserva-form .form-column {
        flex: 1;
    }
    
    .reserva-form .form-column .bordesCampos {
        width: 100%;
    }
    
    .reserva-feedback {
        margin-bottom: 20px;
        padding: 15px;
        border-radius: <?php echo intval($borde_radius); ?>px;
        text-align: center;
    }
    
    .reserva-feedback .updated {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    
    .reserva-feedback .error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    @media (max-width: 768px) {
        .reserva-form .form-group {
            flex-direction: column;
            gap: 0;
        }
        
        .reserva-form {
            padding: 20px;
            margin: 0 15px;
        }
        
        .reserva-form .bordesCampos {
            font-size: 16px;
            padding: 14px 18px;
        }
        
        .reserva-form .iti__selected-flag {
            padding: 0 10px !important;
            width: 70px !important;
            min-width: 70px !important;
            max-width: 70px !important;
        }
        
        .reserva-form .iti input[type="tel"] {
            padding: 14px 18px 14px 82px !important;
            font-size: 16px !important;
        }
        
        .reserva-form button[type="submit"] {
            padding: 16px 24px;
            font-size: 15px;
        }
        
        .reserva-form .phone-group {
            width: 100% !important;
        }
    }
    </style>

    <div class="reserva-form">
        <h3><?php echo esc_html($titulo_formulario); ?></h3>
        
        <?php if (!empty($feedback)): ?>
            <div class="reserva-feedback">
                <?php echo $feedback; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="hidden" name="reserva_mesas_form" value="1">

            <label class="CamposLabel" for="nombre_cliente">Nombre Completo:</label>
            <input class="bordesCampos" type="text" name="nombre_cliente" placeholder="Nombre" required>

            <label class="CamposLabel" for="email_cliente">Correo Electrónico:</label>
            <input class="bordesCampos" type="email" name="email_cliente" placeholder="Correo Electrónico" required>

            <div class="form-group">
                <div class="form-column">
                    <label class="CamposLabel" for="telefono_cliente">Teléfono:</label>
                    <div class="phone-group">
                        <input type="hidden" id="telefono_prefijo" name="telefono_prefijo" value="+57">
                        <input class="bordesCampos" id="telefono_cliente" type="tel" name="telefono_cliente" placeholder="Número de teléfono" required pattern="[0-9]{7,15}" title="Número de teléfono válido">
                    </div>
                </div>

                <div class="form-column">
                    <label class="CamposLabel" for="cantidad_personas">Personas:</label>
                    <select class="bordesCampos" name="cantidad_personas" required>
                        <option value="">Cantidad de personas</option>
                        <?php
                        for ($i = 1; $i <= $max_personas; $i++) {
                            echo "<option value='$i'>$i persona(s)</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <div class="form-column">
                    <label class="CamposLabel" for="fecha_reserva">Fecha de Reserva:</label>
                    <input class="bordesCampos" type="text" name="fecha_reserva" id="fecha_reserva" required placeholder="Selecciona una fecha">
                </div>

                <div class="form-column">
                    <label class="CamposLabel" for="hora_reserva">Hora de Reserva:</label>
                    <select class="bordesCampos" name="hora_reserva" required>
                        <option value="">Selecciona una hora</option>
                        <?php
                        foreach ($horas_disponibles as $hora) {
                            echo "<option value='$hora'>$hora</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <button type="submit"><?php echo esc_html($texto_boton); ?></button>
            <p class="CamposLabel" style="text-align: center; margin-top: 15px; font-size: 12px;">
                <strong>*Para reservas de más de <?php echo $max_personas; ?> personas contáctanos por WhatsApp</strong>
            </p>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var input = document.querySelector("#telefono_cliente");
            var iti = window.intlTelInput(input, {
                initialCountry: "co",
                preferredCountries: ["co", "us", "es", "gb", "mx", "ec", "ve"],
                separateDialCode: true,
                nationalMode: false,
                formatOnDisplay: true,
                autoPlaceholder: "aggressive",
                utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@18.1.1/build/js/utils.js"
            });

            input.addEventListener("countrychange", function () {
                var countryData = iti.getSelectedCountryData();
                document.getElementById("telefono_prefijo").value = "+" + countryData.dialCode;
            });

            // Inicializar con el código de país por defecto
            document.getElementById("telefono_prefijo").value = "+" + iti.getSelectedCountryData().dialCode;

            const diasBloqueados = <?php echo $dias_bloqueados_json; ?>;
            const diasCerrados = <?php echo $dias_cerrados_json; ?>;

            const mapaDias = {
                'sunday': 0,
                'monday': 1,
                'tuesday': 2,
                'wednesday': 3,
                'thursday': 4,
                'friday': 5,
                'saturday': 6
            };

            const diasCerradosNumeros = diasCerrados.map(dia => mapaDias[dia]);

            flatpickr("#fecha_reserva", {
                locale: 'es',
                dateFormat: "Y-m-d",
                minDate: "today",
                maxDate: new Date().fp_incr(90),
                disable: [
                    ...diasBloqueados,
                    function (date) {
                        return diasCerradosNumeros.includes(date.getDay());
                    }
                ],
                disableMobile: "true",
                animate: true,
                monthSelectorType: "static",
                ariaDateFormat: "F j, Y",
                onChange: function (selectedDates, dateStr, instance) {
                    // Lógica adicional si es necesario
                },
                nextArrow: '<svg viewBox="0 0 24 24"><path d="M9.4 18.4l-1.4-1.4 5.6-5.6-5.6-5.6 1.4-1.4 7 7z"></path></svg>',
                prevArrow: '<svg viewBox="0 0 24 24"><path d="M14.6 18.4l1.4-1.4-5.6-5.6 5.6-5.6-1.4-1.4-7 7z"></path></svg>'
            });
        });
    </script>

    <?php
    return ob_get_clean();
}

// Función para guardar reservas
function reserva_mesas_guardar_reserva()
{
    $feedback = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reserva_mesas_form'])) {
        $nombre_cliente = sanitize_text_field($_POST['nombre_cliente']);
        $email_cliente = sanitize_email($_POST['email_cliente']);
        $fecha_reserva = sanitize_text_field($_POST['fecha_reserva']);
        $hora_reserva = sanitize_text_field($_POST['hora_reserva']);
        $cantidad_personas = intval($_POST['cantidad_personas']);
        $telefono_prefijo = sanitize_text_field($_POST['telefono_prefijo']);
        $telefono_cliente = sanitize_text_field($_POST['telefono_cliente']);

        if (empty($telefono_prefijo)) {
            $telefono_prefijo = '57';
        }

        $telefono_prefijo = ltrim($telefono_prefijo, '+');
        $telefono_completo = '+' . $telefono_prefijo . ' ' . $telefono_cliente;

        $max_personas = get_option('reserva_mesas_max_personas', 10);
        $hora_inicio = get_option('reserva_mesas_hora_inicio', '17:00');
        $hora_fin = get_option('reserva_mesas_hora_fin', '23:00');

        if ($cantidad_personas < 1 || $cantidad_personas > $max_personas) {
            return "<div class='error'><p>La cantidad de personas debe ser entre 1 y $max_personas.</p></div>";
        }

        if (strtotime($hora_reserva) < strtotime($hora_inicio) || strtotime($hora_reserva) > strtotime($hora_fin)) {
            return "<div class='error'><p>La hora de reserva debe estar entre $hora_inicio y $hora_fin.</p></div>";
        }

        if (empty($telefono_cliente)) {
            return "<div class='error'><p>Por favor, ingresa un número de teléfono válido.</p></div>";
        }

        $reserva = array(
            'nombre_cliente' => $nombre_cliente,
            'email_cliente' => $email_cliente,
            'fecha_reserva' => $fecha_reserva,
            'hora_reserva' => $hora_reserva,
            'cantidad_personas' => $cantidad_personas,
            'telefono_cliente' => $telefono_completo,
        );

        global $wpdb;
        $table_name = $wpdb->prefix . 'reservas';
        $resultado = $wpdb->insert($table_name, $reserva);

        if ($resultado) {
            $feedback = "<div class='updated'><p>¡Reserva realizada con éxito! $nombre_cliente, tu mesa ha sido reservada para el $fecha_reserva a las $hora_reserva para $cantidad_personas persona(s).</p></div>";

            enviar_notificacion_cliente($nombre_cliente, $email_cliente, $fecha_reserva, $hora_reserva, $cantidad_personas);
            enviar_notificacion_admin($nombre_cliente, $email_cliente, $telefono_cliente, $fecha_reserva, $hora_reserva, $cantidad_personas);

            require_once plugin_dir_path(__FILE__) . 'popup_reserva.php';
            echo "<script>
                    mostrarPopup('$nombre_cliente', '$fecha_reserva', '$hora_reserva', '$cantidad_personas');
                  </script>";
        } else {
            $feedback = "<div class='error'><p>Error al guardar la reserva. Por favor, inténtalo nuevamente.</p></div>";
        }
    }

    return $feedback;
}
