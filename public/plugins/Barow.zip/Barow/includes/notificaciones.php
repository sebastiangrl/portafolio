<?php
// Archivo: notificaciones.php

// Función para enviar el correo de confirmación al cliente
function enviar_notificacion_cliente($nombre_cliente, $email_cliente, $fecha_reserva, $hora_reserva, $cantidad_personas)
{
    // Obtiene el nombre de la empresa de los ajustes
    $nombre_empresa = get_option('reserva_mesas_nombre_empresa', 'Nuestro Restaurante');
    $logo_empresa_url = get_option('reserva_mesas_logo_empresa'); // Obtiene la URL del logo
    $email_empresa = get_option('reserva_mesas_email_empresa', 'info@caboleones.com'); // Dirección de correo de la empresa

    $asunto = "Confirmación de Reserva en $nombre_empresa";

    // Mensaje con formato HTML para mejorar la presentación
    $mensaje = "
        <html>
        <head>
            <title>Confirmación de Reserva</title>
            <style>
                body { font-family: Arial, sans-serif; color: #333; }
                .contenido { margin: 20px; }
                .detalle { margin-bottom: 10px; }
                .reserva-info { font-weight: bold; }
            </style>
        </head>
        <body>
            <div class='contenido'>
                <!-- Mostrar logo -->
                <img src='" . esc_url($logo_empresa_url) . "' alt='Logo de la Empresa' class='logo'>
                
                <p>Hola <strong>$nombre_cliente</strong>,</p>

                <p>Tu reserva ha sido confirmada con los siguientes detalles:</p>

                <div class='detalle'>
                    <span class='reserva-info'>Fecha:</span> $fecha_reserva
                </div>
                <div class='detalle'>
                    <span class='reserva-info'>Hora:</span> $hora_reserva
                </div>
                <div class='detalle'>
                    <span class='reserva-info'>Número de personas:</span> $cantidad_personas
                </div>

                <p>Gracias por reservar con nosotros. ¡Esperamos verte pronto!</p>

                <p>Saludos,<br>
                <strong>$nombre_empresa</strong></p>
            </div>
        </body>
        </html>
    ";

    $cabeceras = array('Content-Type: text/html; charset=UTF-8');

    if (!wp_mail($email_cliente, $asunto, $mensaje, $cabeceras)) {
        error_log('Error al enviar la notificación al cliente.');
    }
}

// Función para enviar la notificación de nueva reserva al administrador
function enviar_notificacion_admin($nombre_cliente, $email_cliente, $telefono_cliente, $fecha_reserva, $hora_reserva, $cantidad_personas)
{
    // Obtiene el correo y el nombre de la empresa de los ajustes
    $admin_email = get_option('reserva_mesas_correo_notificaciones', get_option('admin_email'));
    $nombre_empresa = get_option('reserva_mesas_nombre_empresa', 'Nuestro Restaurante');
    $logo_empresa_url = get_option('reserva_mesas_logo_empresa'); // Obtiene la URL del logo

    $asunto = "Nueva Reserva en $nombre_empresa";

    // Mensaje con formato HTML para el administrador
    $mensaje = "
        <html>
        <head>
            <title>Nueva Reserva</title>
            <style>
                body { font-family: Arial, sans-serif; color: #333; }
                .contenido { margin: 20px; }
                .detalle { margin-bottom: 10px; }
                .reserva-info { font-weight: bold; }
                .header { background-color: #f0f0f0; padding: 15px; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class='contenido'>
                <!-- Mostrar logo -->
                <img src='" . esc_url($logo_empresa_url) . "' alt='Logo de la Empresa' class='logo'>
                
                <div class='header'>
                    <h2>Nueva Reserva Recibida</h2>
                </div>

                <div class='detalle'>
                    <span class='reserva-info'>Nombre del cliente:</span> $nombre_cliente
                </div>
                <div class='detalle'>
                    <span class='reserva-info'>Email:</span> $email_cliente
                </div>
                <div class='detalle'>
                    <span class='reserva-info'>Teléfono:</span> $telefono_cliente
                </div>
                <div class='detalle'>
                    <span class='reserva-info'>Fecha:</span> $fecha_reserva
                </div>
                <div class='detalle'>
                    <span class='reserva-info'>Hora:</span> $hora_reserva
                </div>
                <div class='detalle'>
                    <span class='reserva-info'>Número de personas:</span> $cantidad_personas
                </div>

                <p>Recuerda revisar el panel de administración para más detalles.</p>

                <p>Saludos,<br>
                <strong>Sistema de Reservas - $nombre_empresa</strong></p>
            </div>
        </body>
        </html>
    ";

    $cabeceras = array('Content-Type: text/html; charset=UTF-8');

    if (!wp_mail($admin_email, $asunto, $mensaje, $cabeceras)) {
        error_log('Error al enviar la notificación al administrador.');
    }
}
