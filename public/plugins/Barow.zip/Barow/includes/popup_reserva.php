<?php
// Archivo: popup_reserva.php
?>
<style>
    .popup-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .popup-overlay.active {
        opacity: 1;
    }

    .popup-contenido {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.7);
        background: white;
        width: 90%;
        max-width: 500px;
        padding: 25px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        text-align: center;
        opacity: 0;
        transition: all 0.3s ease;
    }

    .popup-overlay.active .popup-contenido {
        transform: translate(-50%, -50%) scale(1);
        opacity: 1;
    }

    .popup-header {
        position: relative;
        margin-bottom: 15px;
        padding-bottom: 15px;
        border-bottom: 2px solid #f0f0f1;
    }

    .popup-header h2 {
        margin: 0;
        color: #1d2327;
        font-size: 24px;
    }

    .popup-header .check-icon {
        width: 50px;
        height: 50px;
        background: #4CAF50;
        border-radius: 50%;
        margin: 0 auto 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .popup-header .check-icon svg {
        width: 25px;
        height: 25px;
        color: white;
    }

    .popup-body {
        margin-bottom: 15px;
    }

    .popup-body > p {
        margin: 0 0 10px 0;
        font-size: 14px;
    }

    .reserva-detalles {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
        margin: 10px 0;
    }

    .detalle-item {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px;
        border-bottom: 1px solid #e0e0e0;
    }

    .detalle-item:last-child {
        border-bottom: none;
    }

    .detalle-item .icon {
        width: 24px;
        height: 24px;
        min-width: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #e3f2fd;
        border-radius: 50%;
        color: #1976d2;
    }

    .detalle-item .label {
        font-weight: 500;
        color: #666;
        min-width: 70px;
        text-align: left;
        font-size: 14px;
    }

    .detalle-item .valor {
        color: #1d2327;
        text-align: left;
        flex: 1;
        font-size: 14px;
    }

    .popup-imagen {
        max-width: 100%;
        height: auto;
        margin: 10px 0;
        border-radius: 8px;
    }

    .popup-footer {
        text-align: center;
    }

    .btn_popup {
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #f0f0f1;
        color: #1d2327;
        font-size: 14px;
    }

    .btn_popup:hover {
        background: #e0e0e0;
    }

    @media (max-width: 480px) {
        .popup-contenido {
            padding: 20px 15px;
        }

        .detalle-item {
            padding: 6px;
        }

        .detalle-item .icon {
            width: 20px;
            height: 20px;
            min-width: 20px;
        }

        .detalle-item .label {
            min-width: 60px;
            font-size: 13px;
        }

        .detalle-item .valor {
            font-size: 13px;
        }
    }

    @keyframes checkmark {
        0% { transform: scale(0); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
    }

    .check-icon {
        animation: checkmark 0.5s ease-in-out forwards;
    }
</style>

<script>
function mostrarPopup(nombre, fecha, hora, personas) {
    var popupHTML = `
        <div class="popup-overlay">
            <div class="popup-contenido">
                <div class="popup-header">
                    <div class="check-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 6L9 17l-5-5"></path>
                        </svg>
                    </div>
                    <h2>¡Reserva Confirmada!</h2>
                </div>
                
                <div class="popup-body">
                    <div class="reserva-detalles">
                        <div class="detalle-item">
                            <div class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="12" cy="7" r="4"></circle>
                                </svg>
                            </div>
                            <span class="label">Nombre:</span>
                            <span class="valor">${nombre}</span>
                        </div>
                        
                        <div class="detalle-item">
                            <div class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                    <line x1="16" y1="2" x2="16" y2="6"></line>
                                    <line x1="8" y1="2" x2="8" y2="6"></line>
                                    <line x1="3" y1="10" x2="21" y2="10"></line>
                                </svg>
                            </div>
                            <span class="label">Fecha:</span>
                            <span class="valor">${fecha}</span>
                        </div>
                        
                        <div class="detalle-item">
                            <div class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <polyline points="12 6 12 12 16 14"></polyline>
                                </svg>
                            </div>
                            <span class="label">Hora:</span>
                            <span class="valor">${hora}</span>
                        </div>
                        
                        <div class="detalle-item">
                            <div class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="9" cy="7" r="4"></circle>
                                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                                </svg>
                            </div>
                            <span class="label">Personas:</span>
                            <span class="valor">${personas}</span>
                        </div>
                    </div>`;

    var imagenUrl = '<?php echo esc_url(get_option('popup_imagen_url', '')); ?>';
    var imagenWidth = '<?php echo esc_attr(get_option('popup_imagen_width', 100)); ?>';
    
    if (imagenUrl) {
        popupHTML += `
            <img src="${imagenUrl}" 
                 alt="Imagen personalizada" 
                 class="popup-imagen" 
                 style="width: ${imagenWidth}%">`;
    }

    popupHTML += `
                </div>
                
                <div class="popup-footer">
                    <button class="btn_popup" onclick="cerrarPopup()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M18 6L6 18M6 6l12 12"/>
                        </svg>
                        Cerrar
                    </button>
                </div>
            </div>
        </div>`;

    document.body.insertAdjacentHTML('beforeend', popupHTML);

    setTimeout(function() {
        document.querySelector('.popup-overlay').style.display = 'block';
        setTimeout(function() {
            document.querySelector('.popup-overlay').classList.add('active');
        }, 10);
    }, 100);
}

function cerrarPopup() {
    var popup = document.querySelector('.popup-overlay');
    popup.classList.remove('active');
    setTimeout(function() {
        popup.parentNode.removeChild(popup);
    }, 300);
}
</script>

