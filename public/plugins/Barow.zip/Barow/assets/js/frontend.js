/**
 * JavaScript para el frontend de Barow
 * @author Sebastián Gonzalez
 */

(function($) {
    'use strict';

    // Objeto principal de Barow
    window.BarowFrontend = {
        init: function() {
            this.initFormValidation();
            this.initTelephoneInput();
            this.bindEvents();
        },

        initFormValidation: function() {
            // Validación en tiempo real
            $('#barow-formulario-reserva input[required], #barow-formulario-reserva select[required]').on('blur change', function() {
                BarowFrontend.validateField($(this));
            });
        },

        initTelephoneInput: function() {
            // Inicializar intl-tel-input si está disponible
            if (typeof intlTelInput !== 'undefined') {
                const phoneInput = document.querySelector("#telefono_cliente");
                if (phoneInput) {
                    window.iti = intlTelInput(phoneInput, {
                        preferredCountries: ['co', 'us', 'mx', 'ar', 'cl', 'pe'],
                        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
                        nationalMode: false,
                        formatOnDisplay: true,
                        autoHideDialCode: false,
                        separateDialCode: true
                    });
                }
            }
        },

        bindEvents: function() {
            // Prevenir doble envío
            let formSubmitting = false;
            
            $('#barow-formulario-reserva').on('submit', function(e) {
                e.preventDefault();
                
                if (formSubmitting) {
                    return false;
                }
                
                if (BarowFrontend.validateForm()) {
                    formSubmitting = true;
                    BarowFrontend.submitForm($(this));
                    
                    // Resetear flag después de 3 segundos para permitir reintentos
                    setTimeout(function() {
                        formSubmitting = false;
                    }, 3000);
                }
            });

            // Formatear teléfono al perder el foco
            $('#telefono_cliente').on('blur', function() {
                if (window.iti) {
                    $(this).val(window.iti.getNumber());
                }
            });

            // Actualizar horas disponibles según la fecha
            $('#fecha_reserva').on('change', function() {
                BarowFrontend.updateAvailableHours($(this).val());
            });
        },

        validateField: function($field) {
            const value = $field.val().trim();
            const fieldName = $field.attr('name');
            let isValid = true;
            let message = '';

            // Limpiar errores previos
            $field.removeClass('error');
            $field.next('.field-error').remove();

            // Validaciones específicas
            switch (fieldName) {
                case 'nombre_cliente':
                    if (value.length < 2) {
                        isValid = false;
                        message = 'El nombre debe tener al menos 2 caracteres';
                    }
                    break;

                case 'email_cliente':
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(value)) {
                        isValid = false;
                        message = 'Por favor, ingresa un email válido';
                    }
                    break;

                case 'telefono_cliente':
                    if (window.iti && !window.iti.isValidNumber()) {
                        isValid = false;
                        message = 'Por favor, ingresa un número de teléfono válido';
                    } else if (!window.iti && value.length < 7) {
                        isValid = false;
                        message = 'El teléfono debe tener al menos 7 dígitos';
                    }
                    break;

                case 'cantidad_personas':
                    const personas = parseInt(value);
                    if (personas < 1 || personas > 20) {
                        isValid = false;
                        message = 'Selecciona entre 1 y 20 personas';
                    }
                    break;

                case 'fecha_reserva':
                    const selectedDate = new Date(value);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    
                    if (selectedDate < today) {
                        isValid = false;
                        message = 'La fecha no puede ser anterior a hoy';
                    }
                    break;

                case 'hora_reserva':
                    if (!value) {
                        isValid = false;
                        message = 'Selecciona una hora para tu reserva';
                    }
                    break;
            }

            if (!isValid) {
                $field.addClass('error');
                $field.after('<div class="field-error">' + message + '</div>');
            }

            return isValid;
        },

        validateForm: function() {
            let isValid = true;
            
            $('#barow-formulario-reserva input[required], #barow-formulario-reserva select[required]').each(function() {
                if (!BarowFrontend.validateField($(this))) {
                    isValid = false;
                }
            });

            return isValid;
        },

        submitForm: function($form) {
            const submitBtn = $form.find('.barow-btn-submit');
            const btnText = submitBtn.find('.barow-btn-text');
            const btnLoading = submitBtn.find('.barow-btn-loading');
            const mensaje = $('#barow-mensaje');

            // Estado de carga
            submitBtn.prop('disabled', true);
            btnText.hide();
            btnLoading.show();
            mensaje.hide();

            // Preparar datos
            let formData = new FormData($form[0]);
            formData.append('action', 'barow_crear_reserva');

            // Obtener número de teléfono completo
            if (window.iti) {
                formData.set('telefono_cliente', window.iti.getNumber());
            }

            // Enviar AJAX
            $.ajax({
                url: barow_ajax.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                timeout: 30000,
                success: function(response) {
                    if (response.success) {
                        BarowFrontend.showMessage('success', response.data.message);
                        $form[0].reset();
                        
                        // Resetear teléfono
                        if (window.iti) {
                            window.iti.setNumber('');
                        }
                        
                        // Scroll al mensaje
                        $('html, body').animate({
                            scrollTop: mensaje.offset().top - 100
                        }, 500);
                        
                    } else {
                        BarowFrontend.showMessage('error', response.data || barow_ajax.messages.error_general);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error AJAX:', {xhr, status, error});
                    
                    let errorMessage = barow_ajax.messages.error_general;
                    
                    if (status === 'timeout') {
                        errorMessage = 'La solicitud ha tardado demasiado. Por favor, inténtalo de nuevo.';
                    } else if (xhr.status === 0) {
                        errorMessage = 'Error de conexión. Verifica tu conexión a internet.';
                    }
                    
                    BarowFrontend.showMessage('error', errorMessage);
                },
                complete: function() {
                    // Restaurar botón
                    submitBtn.prop('disabled', false);
                    btnText.show();
                    btnLoading.hide();
                }
            });
        },

        showMessage: function(type, message) {
            const mensaje = $('#barow-mensaje');
            mensaje.removeClass('barow-success barow-error barow-info')
                   .addClass('barow-' + type)
                   .html(message)
                   .fadeIn();

            // Auto-hide success messages
            if (type === 'success') {
                setTimeout(function() {
                    mensaje.fadeOut();
                }, 5000);
            }
        },

        updateAvailableHours: function(selectedDate) {
            if (!selectedDate) return;

            // Aquí podrías hacer una llamada AJAX para obtener horas disponibles
            // basadas en reservas existentes para esa fecha
            console.log('Fecha seleccionada:', selectedDate);
        }
    };

    // Inicializar cuando el DOM esté listo
    $(document).ready(function() {
        BarowFrontend.init();
    });

    // Manejo de errores globales
    window.addEventListener('error', function(e) {
        console.error('Error de JavaScript:', e.error);
    });

})(jQuery);

// CSS dinámico para validación
const style = document.createElement('style');
style.textContent = `
    .barow-field input.error,
    .barow-field select.error {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1) !important;
    }
    
    .field-error {
        color: #dc3545;
        font-size: 12px;
        margin-top: 4px;
        display: block;
        animation: fadeInError 0.3s ease;
    }
    
    @keyframes fadeInError {
        from {
            opacity: 0;
            transform: translateY(-5px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .barow-field input:valid {
        border-color: #28a745 !important;
    }
    
    .barow-btn-submit:disabled {
        opacity: 0.7;
        cursor: not-allowed;
    }
`;
document.head.appendChild(style);
