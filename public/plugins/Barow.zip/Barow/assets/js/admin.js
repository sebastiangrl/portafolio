/**
 * JavaScript para el panel de administración de Barow
 * @author Sebastián Gonzalez
 */

(function($) {
    'use strict';

    // Objeto principal del admin
    window.BarowAdmin = {
        init: function() {
            this.bindEvents();
            this.initTooltips();
            this.initBulkActions();
            this.initModals();
            this.initClipboard();
        },

        bindEvents: function() {
            // Seleccionar/deseleccionar todos
            $('#select_all, #select_all_reservas').on('change', function() {
                const isChecked = $(this).is(':checked');
                $('.reserva-checkbox, .reserva_checkbox').prop('checked', isChecked);
                BarowAdmin.updateBulkActionsVisibility();
            });

            // Cambio en checkboxes individuales
            $(document).on('change', '.reserva-checkbox, .reserva_checkbox', function() {
                BarowAdmin.updateSelectAllState();
                BarowAdmin.updateBulkActionsVisibility();
            });

            // Botones de edición
            $(document).on('click', '.editar-reserva', function(e) {
                e.preventDefault();
                BarowAdmin.openEditModal($(this));
            });

            // Confirmaciones de eliminación
            $(document).on('click', '.button-danger, [href*="eliminar"]', function(e) {
                if (!confirm('¿Estás seguro de que quieres eliminar este elemento? Esta acción no se puede deshacer.')) {
                    e.preventDefault();
                    return false;
                }
            });

            // Confirmaciones de cancelación
            $(document).on('click', '.button-warning, [href*="cancelar"]', function(e) {
                if (!confirm('¿Estás seguro de que quieres cancelar esta reserva?')) {
                    e.preventDefault();
                    return false;
                }
            });

            // Auto-save en formularios
            $('.barow-form input, .barow-form select, .barow-form textarea').on('change', function() {
                BarowAdmin.markFormAsModified($(this).closest('form'));
            });

            // Prevenir pérdida de datos
            window.addEventListener('beforeunload', function(e) {
                if ($('.barow-form.modified').length > 0) {
                    e.preventDefault();
                    e.returnValue = '¿Estás seguro de que quieres salir? Los cambios no guardados se perderán.';
                    return e.returnValue;
                }
            });
        },

        initTooltips: function() {
            // Agregar tooltips a botones sin texto
            $('[title]').each(function() {
                const $this = $(this);
                if (!$this.hasClass('tooltip-initialized')) {
                    $this.addClass('tooltip-initialized');
                    
                    $this.hover(
                        function() {
                            BarowAdmin.showTooltip($(this));
                        },
                        function() {
                            BarowAdmin.hideTooltip();
                        }
                    );
                }
            });
        },

        initBulkActions: function() {
            // Manejar acciones en lote
            $('#reservas-form, form[method="POST"]').on('submit', function(e) {
                const bulkAction = $(this).find('select[name="bulk_action"]').val();
                const selectedItems = $(this).find('.reserva-checkbox:checked, .reserva_checkbox:checked');

                if (bulkAction && selectedItems.length === 0) {
                    e.preventDefault();
                    BarowAdmin.showNotice('error', 'Por favor, selecciona al menos un elemento.');
                    return false;
                }

                if (bulkAction === 'eliminar' && selectedItems.length > 0) {
                    if (!confirm(`¿Estás seguro de que quieres eliminar ${selectedItems.length} elemento(s)? Esta acción no se puede deshacer.`)) {
                        e.preventDefault();
                        return false;
                    }
                }

                if (bulkAction === 'cancelar' && selectedItems.length > 0) {
                    if (!confirm(`¿Estás seguro de que quieres cancelar ${selectedItems.length} reserva(s)?`)) {
                        e.preventDefault();
                        return false;
                    }
                }
            });
        },

        initModals: function() {
            // Cerrar modales
            $(document).on('click', '.modal-close', function() {
                BarowAdmin.closeModal($(this).closest('.barow-modal'));
            });

            // Cerrar modal al hacer clic fuera
            $(document).on('click', '.barow-modal', function(e) {
                if (e.target === this) {
                    BarowAdmin.closeModal($(this));
                }
            });

            // Escape para cerrar modal
            $(document).on('keydown', function(e) {
                if (e.key === 'Escape') {
                    BarowAdmin.closeModal($('.barow-modal:visible'));
                }
            });
        },

        initClipboard: function() {
            // Copiar reserva individual
            $(document).on('click', '.copiar-reserva', function(e) {
                e.preventDefault();
                const detalle = $(this).data('detalle');
                BarowAdmin.copyToClipboard(detalle, 'Información de reserva copiada');
            });

            // Copiar cliente
            $(document).on('click', '.copiar-cliente', function(e) {
                e.preventDefault();
                const cliente = $(this).data('cliente');
                BarowAdmin.copyToClipboard(cliente, 'Información del cliente copiada');
            });

            // Copiar reservas de hoy
            $('#copiar-reservas-hoy').on('click', function(e) {
                e.preventDefault();
                BarowAdmin.copyTodayReservations();
            });
        },

        // Funciones auxiliares
        updateSelectAllState: function() {
            const totalCheckboxes = $('.reserva-checkbox, .reserva_checkbox').length;
            const checkedCheckboxes = $('.reserva-checkbox:checked, .reserva_checkbox:checked').length;
            
            const selectAll = $('#select_all, #select_all_reservas');
            
            if (checkedCheckboxes === 0) {
                selectAll.prop('indeterminate', false).prop('checked', false);
            } else if (checkedCheckboxes === totalCheckboxes) {
                selectAll.prop('indeterminate', false).prop('checked', true);
            } else {
                selectAll.prop('indeterminate', true);
            }
        },

        updateBulkActionsVisibility: function() {
            const selectedCount = $('.reserva-checkbox:checked, .reserva_checkbox:checked').length;
            const bulkActions = $('.barow-bulk-actions');
            
            if (selectedCount > 0) {
                bulkActions.addClass('has-selection');
                bulkActions.find('.selection-count').text(`${selectedCount} seleccionado(s)`);
            } else {
                bulkActions.removeClass('has-selection');
            }
        },

        openEditModal: function($button) {
            const modalId = '#modal-editar';
            const $modal = $(modalId);
            
            if ($modal.length === 0) return;

            // Rellenar datos del modal
            const data = $button.data();
            Object.keys(data).forEach(key => {
                const $field = $modal.find(`#modal-${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`);
                if ($field.length) {
                    $field.val(data[key]);
                }
            });

            // Mostrar modal
            $modal.fadeIn(300);
            $modal.find('input:first').focus();
        },

        closeModal: function($modal) {
            $modal.fadeOut(300);
            
            // Limpiar formulario
            $modal.find('form')[0]?.reset();
            $modal.find('.form-group').removeClass('has-error');
            $modal.find('.field-error').remove();
        },

        copyToClipboard: function(text, successMessage = 'Copiado al portapapeles') {
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function() {
                    BarowAdmin.showNotice('success', successMessage);
                }).catch(function() {
                    BarowAdmin.fallbackCopyToClipboard(text, successMessage);
                });
            } else {
                BarowAdmin.fallbackCopyToClipboard(text, successMessage);
            }
        },

        fallbackCopyToClipboard: function(text, successMessage) {
            const textArea = document.createElement('textarea');
            textArea.value = text;
            textArea.style.position = 'fixed';
            textArea.style.left = '-999999px';
            textArea.style.top = '-999999px';
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                document.execCommand('copy');
                BarowAdmin.showNotice('success', successMessage);
            } catch (err) {
                BarowAdmin.showNotice('error', 'No se pudo copiar al portapapeles');
            }
            
            document.body.removeChild(textArea);
        },

        copyTodayReservations: function() {
            const $button = $('#copiar-reservas-hoy');
            const originalText = $button.text();
            
            $button.prop('disabled', true).text('Copiando...');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'barow_obtener_reservas_hoy',
                    nonce: $('#barow_nonce').val() || wp.ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        BarowAdmin.copyToClipboard(response.data, 'Reservas de hoy copiadas');
                    } else {
                        BarowAdmin.showNotice('error', 'Error al obtener las reservas de hoy');
                    }
                },
                error: function() {
                    BarowAdmin.showNotice('error', 'Error de conexión');
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        },

        showTooltip: function($element) {
            const title = $element.attr('title');
            if (!title) return;

            const $tooltip = $('<div class="barow-tooltip">' + title + '</div>');
            $('body').append($tooltip);

            const offset = $element.offset();
            const elementHeight = $element.outerHeight();
            const tooltipWidth = $tooltip.outerWidth();
            const tooltipHeight = $tooltip.outerHeight();

            $tooltip.css({
                top: offset.top - tooltipHeight - 10,
                left: offset.left + ($element.outerWidth() / 2) - (tooltipWidth / 2)
            }).fadeIn(200);

            // Remover title para evitar tooltip nativo
            $element.data('original-title', title).removeAttr('title');
        },

        hideTooltip: function() {
            $('.barow-tooltip').fadeOut(200, function() {
                $(this).remove();
            });

            // Restaurar titles
            $('[data-original-title]').each(function() {
                $(this).attr('title', $(this).data('original-title')).removeData('original-title');
            });
        },

        showNotice: function(type, message) {
            // Remover notificaciones existentes
            $('.barow-notice').remove();

            const $notice = $(`
                <div class="barow-notice barow-notice-${type}">
                    <span class="dashicons ${type === 'success' ? 'dashicons-yes' : type === 'error' ? 'dashicons-warning' : 'dashicons-info'}"></span>
                    ${message}
                    <button type="button" class="notice-dismiss">
                        <span class="dashicons dashicons-dismiss"></span>
                    </button>
                </div>
            `);

            // Insertar después del header
            $('.barow-header').after($notice);

            // Auto-hide después de 5 segundos
            setTimeout(function() {
                $notice.fadeOut(300, function() {
                    $(this).remove();
                });
            }, 5000);

            // Botón de cerrar
            $notice.find('.notice-dismiss').on('click', function() {
                $notice.fadeOut(300, function() {
                    $(this).remove();
                });
            });
        },

        markFormAsModified: function($form) {
            $form.addClass('modified');
        },

        // Función para filtros dinámicos
        applyFilters: function() {
            const estado = $('#estado_filtro').val();
            const perPage = $('#per_page').val();
            const currentUrl = new URL(window.location);
            
            currentUrl.searchParams.set('estado_filtro', estado);
            currentUrl.searchParams.set('per_page', perPage);
            currentUrl.searchParams.delete('paged'); // Reset pagination
            
            window.location.href = currentUrl.toString();
        },

        // Búsqueda en tiempo real
        initSearch: function() {
            const $searchInput = $('#barow-search');
            let searchTimeout;

            $searchInput.on('input', function() {
                clearTimeout(searchTimeout);
                const query = $(this).val();

                searchTimeout = setTimeout(function() {
                    if (query.length >= 3 || query.length === 0) {
                        BarowAdmin.performSearch(query);
                    }
                }, 500);
            });
        },

        performSearch: function(query) {
            // Implementar búsqueda AJAX si es necesario
            console.log('Buscando:', query);
        }
    };

    // Inicializar cuando el DOM esté listo
    $(document).ready(function() {
        BarowAdmin.init();
        
        // Hacer función global para los filtros
        window.aplicarFiltros = BarowAdmin.applyFilters;
    });

    // Manejo de errores AJAX global
    $(document).ajaxError(function(event, xhr, settings, error) {
        console.error('Error AJAX:', {event, xhr, settings, error});
        
        if (xhr.status === 403) {
            BarowAdmin.showNotice('error', 'No tienes permisos para realizar esta acción.');
        } else if (xhr.status === 500) {
            BarowAdmin.showNotice('error', 'Error interno del servidor. Por favor, contacta al administrador.');
        }
    });

})(jQuery);

// CSS dinámico para tooltips y notificaciones
const adminStyle = document.createElement('style');
adminStyle.textContent = `
    .barow-tooltip {
        position: absolute;
        background: #333;
        color: white;
        padding: 8px 12px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 99999;
        white-space: nowrap;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    
    .barow-tooltip::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
        border: 5px solid transparent;
        border-top-color: #333;
    }
    
    .barow-bulk-actions {
        transition: all 0.3s ease;
    }
    
    .barow-bulk-actions:not(.has-selection) {
        opacity: 0.6;
        pointer-events: none;
    }
    
    .barow-notice {
        animation: slideDown 0.3s ease;
    }
    
    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .notice-dismiss {
        background: none;
        border: none;
        cursor: pointer;
        padding: 5px;
        margin-left: auto;
    }
    
    .barow-form.modified {
        position: relative;
    }
    
    .barow-form.modified::before {
        content: '';
        position: absolute;
        top: -3px;
        left: -3px;
        right: -3px;
        bottom: -3px;
        border: 2px solid #ff9800;
        border-radius: 8px;
        pointer-events: none;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
`;
document.head.appendChild(adminStyle);
