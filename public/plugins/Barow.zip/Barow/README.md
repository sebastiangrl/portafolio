# 🍽️ Barow - Sistema de Reservas para Restaurantes

![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-blue.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)
![License](https://img.shields.io/badge/license-GPL%20v2%2B-green.svg)

**Barow** es un sistema completo de gestión de reservas diseñado específicamente para restaurantes, bares y establecimientos gastronómicos. Permite a tus clientes hacer reservas online de manera fácil y rápida, mientras te proporciona herramientas avanzadas de gestión y analytics.

## ✨ Características Principales

### 🎯 **Para tus Clientes**
- **Formulario de reserva intuitivo** con validación en tiempo real
- **Selector de fecha y hora** fácil de usar
- **Confirmación inmediata** por email
- **Diseño responsive** que funciona en todos los dispositivos

### 🛠️ **Para tu Restaurante**
- **Panel de administración completo** integrado en WordPress
- **Gestión centralizada** de todas las reservas
- **Sistema de notificaciones** por email automáticas
- **Analytics avanzados** para optimizar tu negocio
- **Herramientas de exportación** para integrar con otros sistemas

### 📊 **Analytics y Reportes**
- **Estadísticas en tiempo real** de reservas y clientes
- **Gráficos de tendencias** para identificar patrones
- **Análisis por días** de la semana y horarios
- **Métricas de eficiencia** y tasa de cancelación
- **Ranking de clientes** más frecuentes

### 🎨 **Diseño Profesional**
- **Interfaz moderna** y fácil de usar
- **Colores personalizables** para cada día de la semana
- **Iconos intuitivos** de WordPress Dashicons
- **Animaciones suaves** y efectos visuales
- **Modo responsive** para gestión móvil

## 🚀 Instalación

### Instalación Manual

1. **Descarga** el plugin desde este repositorio
2. **Sube** la carpeta `barow` a `/wp-content/plugins/`
3. **Activa** el plugin desde el panel de WordPress
4. **Configura** las opciones desde el menú "Reservas"

### Desde WordPress

1. Ve a **Plugins > Añadir nuevo**
2. Busca **"Barow"**
3. **Instala** y **activa** el plugin
4. **Configura** desde el menú "Reservas"

## ⚙️ Configuración Inicial

### 1. Configuración Básica

Después de activar el plugin:

1. Ve a **Reservas > Ajustes**
2. Configura tu **información de contacto**
3. Personaliza los **colores y estilos**
4. Establece **horarios de funcionamiento**

### 2. Agregar el Formulario

Para mostrar el formulario de reservas en tu sitio web, usa el shortcode:

```shortcode
[barow_formulario_reservas]
```

Puedes agregarlo en:
- **Páginas** de WordPress
- **Entradas** del blog  
- **Widgets** de texto
- **Plantillas** PHP con `do_shortcode()`

### 3. Personalización Avanzada

El plugin incluye opciones de personalización en **Reservas > Personalización**:

- **Colores** del formulario
- **Textos** personalizados
- **Validaciones** específicas
- **Integraciones** con otros plugins

## 📋 Uso del Plugin

### Panel de Administración

El plugin agrega un menú **"Reservas"** en WordPress con las siguientes secciones:

#### 🎯 **Todas las Reservas**
- **Lista completa** de reservas con filtros avanzados
- **Búsqueda** por cliente, email o teléfono
- **Filtrado** por estado y fechas
- **Acciones rápidas**: editar, cancelar, eliminar
- **Exportación** individual o grupal al portapapeles
- **Sistema de labels "Nuevo"** para control visual

#### 👥 **Clientes**
- **Base de datos** de todos tus clientes
- **Historial** de reservas por cliente
- **Estadísticas** de frecuencia de visitas
- **Información de contacto** centralizada

#### 📊 **Analytics**
- **Dashboard** con métricas en tiempo real
- **Gráficos** de horarios más populares
- **Análisis** por días de la semana
- **Tendencias** de los últimos 30 días
- **Top clientes** más frecuentes
- **Evolución mensual** de los últimos 12 meses

#### ⚙️ **Ajustes**
- **Configuración** general del plugin
- **Notificaciones** por email
- **Parámetros** de funcionamiento

#### 🎨 **Personalización**
- **Estilos** del formulario
- **Colores** personalizados
- **Textos** modificables

### Funciones Avanzadas

#### 🔄 **Sistema de Estados**
Las reservas tienen estados automáticos:
- **Activa**: Reserva confirmada y vigente
- **Pasada**: Reserva que ya ocurrió (cambio automático)
- **Cancelada**: Reserva cancelada manualmente

#### � **Notificaciones Automáticas**
- **Email de confirmación** al cliente
- **Notificación** al restaurante
- **Plantillas** personalizables

#### 📱 **Herramientas de Productividad**
- **Copiado rápido** de reservas al portapapeles
- **Export masivo** de reservas del día
- **Labels "Nuevo"** para control visual
- **Filtros inteligentes** para búsquedas

## 🎨 Personalización

### Shortcode con Parámetros

```shortcode
[barow_formulario_reservas titulo="Reserva tu Mesa" mostrar_titulo="true"]
```

### CSS Personalizado

El plugin usa clases CSS con prefijo `barow-` para fácil personalización:

```css
.barow-formulario {
    /* Personaliza el formulario */
}

.barow-admin {
    /* Personaliza el panel admin */
}
```

### Hooks para Desarrolladores

```php
// Acción después de crear una reserva
do_action('barow_reserva_creada', $reserva_id, $datos_reserva);

// Filtro para modificar datos antes de guardar
apply_filters('barow_datos_reserva', $datos, $form_data);
```

## 🛡️ Seguridad

El plugin implementa las mejores prácticas de seguridad:

- ✅ **Validación** y sanitización de datos
- ✅ **Nonces** para prevenir CSRF
- ✅ **Preparación** de consultas SQL
- ✅ **Escape** de datos de salida
- ✅ **Verificación** de permisos de usuario

## 🔧 Requisitos Técnicos

### Mínimos
- **WordPress**: 5.0 o superior
- **PHP**: 7.4 o superior
- **MySQL**: 5.6 o superior
- **Memoria PHP**: 128MB mínimo

### Recomendados
- **WordPress**: 6.0 o superior
- **PHP**: 8.0 o superior
- **MySQL**: 8.0 o superior
- **Memoria PHP**: 256MB o superior

## � Solución de Problemas

### Problemas Comunes

**❓ El formulario no aparece**
- Verifica que hayas usado el shortcode correcto: `[barow_formulario_reservas]`
- Comprueba que el plugin esté activado

**❓ No llegan los emails**
- Verifica la configuración SMTP de WordPress
- Revisa la carpeta de spam
- Contacta con tu proveedor de hosting

**❓ Los estilos no se cargan**
- Limpia la caché del navegador (Ctrl+F5)
- Verifica permisos de archivos CSS
- Desactiva y reactiva el plugin

**❓ Error de base de datos**
- Desactiva y reactiva el plugin para recrear tablas
- Verifica permisos de la base de datos

### Soporte

Si necesitas ayuda:

1. 📖 Revisa esta documentación
2. 🔍 Busca en los [Issues](https://github.com/sebastiangrl/barow/issues) existentes
3. 🆕 Crea un [nuevo Issue](https://github.com/sebastiangrl/barow/issues/new) con detalles
4. 📧 Contacta: sebastiangrl@gmail.com

## 🤝 Contribuir

¡Las contribuciones son bienvenidas! Si quieres mejorar Barow:

### Cómo Contribuir

1. **Fork** este repositorio
2. **Crea** una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. **Commit** tus cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. **Push** a la rama (`git push origin feature/nueva-funcionalidad`)
5. **Crea** un Pull Request

### Tipos de Contribuciones

- � **Bug fixes**
- ✨ **Nuevas características**
- 📝 **Documentación**
- 🌍 **Traducciones**
- 🎨 **Mejoras de diseño**
- ⚡ **Optimizaciones de rendimiento**

### Estándares de Código

- Sigue los **WordPress Coding Standards**
- **Comenta** tu código adecuadamente
- **Testea** tus cambios antes del PR
- **Actualiza** la documentación si es necesario

## 📝 Changelog

### Versión 2.0.0 (Actual)
- ✨ **Nuevo**: Sistema completo de analytics
- ✨ **Nuevo**: Gestión avanzada de clientes  
- ✨ **Nuevo**: Herramientas de exportación
- ✨ **Nuevo**: Sistema de labels "Nuevo"
- ✨ **Nuevo**: Filtros avanzados de búsqueda
- 🎨 **Mejorado**: Diseño completamente renovado
- 🎨 **Mejorado**: Interfaz responsive
- ⚡ **Optimizado**: Rendimiento de consultas
- 🔧 **Corregido**: Múltiples bugs menores

### Roadmap Futuro
- 🔮 **v2.1**: Integración con calendarios externos
- 🔮 **v2.2**: App móvil para gestión
- 🔮 **v2.3**: Integración con sistemas de pago
- � **v2.4**: API REST completa

## 📄 Licencia

Este proyecto está licenciado bajo la **GNU General Public License v2.0 o posterior**.

```
Copyright (C) 2025 Sebastián González

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.
```

Ver [LICENSE](LICENSE) para más detalles.

## 🙏 Agradecimientos

- **WordPress Community** por la plataforma base
- **Dashicons** por el sistema de iconos
- **Contribuidores** que han mejorado el plugin
- **Usuarios** que reportan bugs y sugieren mejoras

## 📞 Contacto

- **Autor**: Sebastián González
- **Email**: sebastiangrl@gmail.com
- **Website**: [jsebastiangonzalez.com](https://www.jsebastiangonzalez.com/)
- **GitHub**: [@sebastiangrl](https://github.com/sebastiangrl)

---

⭐ **¿Te gusta Barow?** ¡Dale una estrella en GitHub y compártelo con otros restaurantes!

🍽️ **¿Usas Barow en tu restaurante?** ¡Nos encantaría saberlo! Envíanos un mensaje.

💝 **¿Quieres apoyar el desarrollo?** Considera hacer una [donación](https://paypal.me/sebastiangrl) o contribuir al código.
- 📅 **Copia rápida** - Botón para copiar todas las reservas del día actual
- ✉️ **Notificaciones automáticas** - Email a clientes y administradores
- 🎨 **Personalización avanzada** - Colores, bordes y estilos configurables
- 🔒 **Roles y permisos** - Sistema de roles para gestores de reservas

## Novedades Versión 1.1.0
- ✨ **Nueva pestaña "Clientes"** - Gestión completa de base de datos de clientes
- 🚫 **Prevención de reservas duplicadas** - Sistema inteligente que evita reservas duplicadas en horarios similares
- 🎯 **Iconos modernos** - Reemplazados emojis por iconos profesionales de Dashicons
- 📄 **Paginación avanzada** - Control total sobre la cantidad de elementos mostrados
- 📋 **Botón copiar reservas del día** - Copia todas las reservas del día actual con un clic
- 🏗️ **Estructura mejorada** - Código reorganizado y optimizado para mejor rendimiento
- 🔧 **Nueva información del autor** - Actualizado a Sebastián Gonzalez

## Instalación
1. Descarga el plugin desde [jsebastiangonzalez.com/plugins](https://www.jsebastiangonzalez.com/plugins)
2. Sube la carpeta `barow` a `/wp-content/plugins/`
3. Activa el plugin desde el panel de WordPress
4. Ve a **Reservas** en el menú de administración para comenzar

## Uso del Plugin

### Formulario de Reserva
Usa el shortcode `[formulario_reserva]` en cualquier página o entrada:

```php
// Formulario básico
[formulario_reserva]

// Con título personalizado
[formulario_reserva titulo_personalizado="Reserva tu Mesa Ahora"]

// Sin título
[formulario_reserva mostrar_titulo="false"]

// Con clase CSS personalizada
[formulario_reserva clase_css="mi-clase-personalizada"]
```

### Panel de Administración

#### Gestión de Reservas
- **Filtros avanzados**: Por estado (activas, hoy, futuras, pasadas, canceladas)
- **Paginación**: Configurable de 10 a 100 reservas por página
- **Acciones rápidas**: Editar, cancelar, eliminar reservas
- **Copia rápida**: Copiar información de reservas individuales o del día completo
- **Exportación**: Exportar reservas seleccionadas a CSV

#### Gestión de Clientes
- **Base de datos unificada**: Sin duplicados, usando email como identificador único
- **Estadísticas**: Total clientes, nuevos del mes, clientes frecuentes
- **Exportación CSV**: Toda la base de datos de clientes
- **Historial**: Ver todas las reservas de cada cliente

### Configuración

#### Ajustes Generales
- Número máximo de personas por reserva
- Horarios de atención (inicio y fin)
- Días cerrados
- Configuración de notificaciones por email

#### Personalización Visual
- Colores de bordes y botones
- Radio de bordes
- Colores de texto y etiquetas
- Estilos CSS personalizados

## Características Técnicas

### Prevención de Duplicados
El sistema verifica automáticamente:
- Mismo cliente (por email)
- Misma fecha
- Horario similar (±30 minutos)
- Estado activo de la reserva

### Base de Datos Optimizada
- **Tabla de reservas**: Información completa de cada reserva
- **Tabla de clientes**: Base de datos sin duplicados
- **Índices optimizados**: Para consultas rápidas
- **Migración automática**: De versiones anteriores

### Seguridad y Permisos
- **Roles personalizados**: Gestor de reservas con permisos específicos
- **Verificación de nonces**: Protección CSRF en todas las acciones
- **Sanitización de datos**: Todos los inputs son limpiados y validados
- **Capacidades granulares**: Control fino de permisos

## Hooks y Filtros para Desarrolladores

### Actions
```php
// Después de crear una reserva
do_action('barow_reserva_creada', $reserva_id, $cliente_id);

// Después de cancelar una reserva
do_action('barow_reserva_cancelada', $reserva_id);

// Después de crear un cliente
do_action('barow_cliente_creado', $cliente_id);
```

### Filters
```php
// Modificar campos del formulario
$campos = apply_filters('barow_campos_formulario', $campos_default);

// Modificar validaciones
$is_valid = apply_filters('barow_validar_reserva', true, $datos_reserva);

// Modificar mensaje de confirmación
$mensaje = apply_filters('barow_mensaje_confirmacion', $mensaje_default, $reserva);
```

## Soporte y Desarrollo

### Autor
**Sebastián Gonzalez**
- 🌐 Website: [jsebastiangonzalez.com](https://www.jsebastiangonzalez.com/)
- 📦 Plugins: [jsebastiangonzalez.com/plugins](https://www.jsebastiangonzalez.com/plugins)

### Requisitos del Sistema
- WordPress 5.0 o superior
- PHP 7.4 o superior
- MySQL 5.6 o superior
- Recomendado: WordPress 6.0+ y PHP 8.0+

### Compatibilidad
- ✅ WordPress 6.4
- ✅ PHP 8.2
- ✅ Multisite
- ✅ Todos los temas de WordPress
- ✅ Constructores de páginas (Elementor, Gutenberg, etc.)

## Changelog

### Versión 1.1.0 (2025-01-04)
- **NUEVO**: Módulo completo de gestión de clientes
- **NUEVO**: Prevención inteligente de reservas duplicadas
- **NUEVO**: Paginación configurable (10, 30, 50, 100 elementos)
- **NUEVO**: Botón para copiar reservas del día actual
- **MEJORADO**: Iconos profesionales reemplazan emojis
- **MEJORADO**: Estructura de código completamente reorganizada
- **MEJORADO**: Sistema de base de datos optimizado
- **MEJORADO**: Interfaz de usuario más moderna y responsive
- **ACTUALIZADO**: Información del autor y enlaces

### Versión 1.0.8 (Anterior)
- Sistema básico de reservas
- Dashboard simple
- Notificaciones por email
- Personalización básica

## Licencia
Este plugin está licenciado bajo GPL v2 o posterior.

## Agradecimientos
Gracias a todos los restaurantes y bares que han confiado en Barow para gestionar sus reservas. Su feedback ha sido fundamental para estas mejoras.