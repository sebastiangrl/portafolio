/**
 * JavaScript para el panel de administración de Barow
 * Incluye funcionalidades modernas con iconos y prevención de duplicados
 */

(function($) {
    'use strict';
    
    const BarowAdmin = {
        
        init: function() {
            this.bindEvents();
            this.initFilters();
            this.initPagination();
            this.initCopyButton();
            this.initTooltips();
        },
        
        bindEvents: function() {
            // Botón de copiar reservas del día
            $(document).on('click', '.barow-copy-day', this.copyReservasHoy);
            
            // Botón de copiar reserva individual
            $(document).on('click', '.barow-copy-individual', this.copyReservaIndividual);
            
            // Botón de copiar original (compatibilidad)
            $(document).on('click', '.copiar_reserva', function() {
                var detalle = $(this).data('detalle');
                navigator.clipboard.writeText(detalle).then(function () {
                    alert('Reserva copiada al portapapeles');
                }).catch(function (err) {
                    console.error('Error al copiar: ', err);
                });
            });
            
            // Filtros de reservas
            $(document).on('change', '.barow-filter-select', this.filterReservas);
            
            // Búsqueda de clientes
            $(document).on('keyup', '.barow-search-input', this.debounce(this.searchClientes, 300));
            
            // Acciones de reservas
            $(document).on('click', '.barow-cancel-reserva', this.cancelarReserva);
            $(document).on('click', '.barow-delete-reserva', this.eliminarReserva);
            
            // Modal de detalles
            $(document).on('click', '.barow-view-details', this.showReservaDetails);
        },
        
        initFilters: function() {
            // Agregar iconos a los filtros
            $('.barow-filters').each(function() {
                $(this).prepend('<span class="dashicons dashicons-filter"></span>');
            });
        },
        
        initPagination: function() {
            // Mejorar paginación con AJAX
            $(document).on('click', '.barow-pagination a', function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                BarowAdmin.loadPage(page);
            });
        },
        
        initCopyButton: function() {
            // Crear botón de copiar con icono
            if ($('.barow-reservas-hoy').length) {
                const copyButton = `
                    <button class="button button-primary barow-copy-day" style="margin-left: 10px;">
                        <span class="dashicons dashicons-clipboard" style="margin-right: 5px;"></span>
                        Copiar Reservas del Día
                    </button>
                `;
                $('.barow-reservas-hoy .page-title-action').after(copyButton);
            }
        },
        
        initTooltips: function() {
            // Inicializar tooltips para iconos
            $('[data-tooltip]').each(function() {
                $(this).attr('title', $(this).data('tooltip'));
            });
        },
        
        copyReservasHoy: function(e) {
            e.preventDefault();
            
            const $button = $(this);
            const originalText = $button.html();
            
            $button.html('<span class="dashicons dashicons-update spin"></span> Copiando...');
            $button.prop('disabled', true);
            
            // Obtener fecha actual
            const hoy = new Date();
            const fechaHoy = hoy.getFullYear() + '-' + 
                          String(hoy.getMonth() + 1).padStart(2, '0') + '-' + 
                          String(hoy.getDate()).padStart(2, '0');
            
            // Buscar reservas de hoy en la tabla
            const reservasHoy = [];
            $('tbody tr').each(function() {
                const fechaReserva = $(this).find('[data-fecha]').data('fecha');
                if (fechaReserva === fechaHoy) {
                    const nombre = $(this).find('td:eq(0)').text().trim();
                    const email = $(this).find('td:eq(1)').text().trim();
                    const telefono = $(this).find('td:eq(2)').text().trim();
                    const fecha = $(this).find('td:eq(3)').text().trim();
                    const dia = $(this).find('td:eq(4)').text().trim();
                    const hora = $(this).find('td:eq(5)').text().trim();
                    const personas = $(this).find('td:eq(6)').text().trim();
                    const estado = $(this).find('td:eq(7) .barow-status').text().trim();
                    
                    reservasHoy.push({
                        nombre, email, telefono, fecha, dia, hora, personas, estado
                    });
                }
            });
            
            if (reservasHoy.length === 0) {
                BarowAdmin.showNotification('No hay reservas para hoy', 'warning');
                $button.html(originalText);
                $button.prop('disabled', false);
                return;
            }
            
            // Crear texto para copiar
            let texto = `RESERVAS DE HOY (${fechaHoy})\n`;
            texto += '='.repeat(50) + '\n\n';
            
            reservasHoy.forEach(function(reserva, index) {
                texto += `${index + 1}. ${reserva.nombre}\n`;
                texto += `   Email: ${reserva.email}\n`;
                texto += `   Teléfono: ${reserva.telefono}\n`;
                texto += `   Fecha: ${reserva.fecha} (${reserva.dia})\n`;
                texto += `   Hora: ${reserva.hora}\n`;
                texto += `   Personas: ${reserva.personas}\n`;
                texto += `   Estado: ${reserva.estado}\n\n`;
            });
            
            texto += `Total de reservas: ${reservasHoy.length}`;
            
            // Copiar al portapapeles
            if (navigator.clipboard) {
                navigator.clipboard.writeText(texto).then(function() {
                    BarowAdmin.showNotification(`¡${reservasHoy.length} reservas copiadas al portapapeles!`, 'success');
                    $button.html('<span class="dashicons dashicons-yes"></span> ¡Copiado!');
                    
                    setTimeout(function() {
                        $button.html(originalText);
                        $button.prop('disabled', false);
                    }, 2000);
                }).catch(function() {
                    BarowAdmin.showTextModal('Reservas del Día', texto);
                    $button.html(originalText);
                    $button.prop('disabled', false);
                });
            } else {
                BarowAdmin.showTextModal('Reservas del Día', texto);
                $button.html(originalText);
                $button.prop('disabled', false);
            }
        },

        copyReservaIndividual: function(e) {
            e.preventDefault();
            
            const $button = $(this);
            const $row = $button.closest('tr');
            
            // Obtener datos de la reserva
            const nombre = $row.find('td:eq(0)').text().trim();
            const email = $row.find('td:eq(1)').text().trim();
            const telefono = $row.find('td:eq(2)').text().trim();
            const fecha = $row.find('td:eq(3)').text().trim();
            const dia = $row.find('td:eq(4)').text().trim();
            const hora = $row.find('td:eq(5)').text().trim();
            const personas = $row.find('td:eq(6)').text().trim();
            const estado = $row.find('td:eq(7) .barow-status').text().trim();
            
            var reservaData = {
                nombre: nombre,
                email: email,
                telefono: telefono,
                fecha: fecha,
                dia: dia,
                hora: hora,
                personas: personas,
                estado: estado
            };

            var texto = 'RESERVA\n' +
                       'Nombre: ' + reservaData.nombre + '\n' +
                       'Email: ' + reservaData.email + '\n' +
                       'Teléfono: ' + reservaData.telefono + '\n' +
                       'Fecha: ' + reservaData.fecha + ' (' + reservaData.dia + ')\n' +
                       'Hora: ' + reservaData.hora + '\n' +
                       'Personas: ' + reservaData.personas + '\n' +
                       'Estado: ' + reservaData.estado;
            
            // Copiar al portapapeles
            if (navigator.clipboard) {
                navigator.clipboard.writeText(texto).then(function() {
                    BarowAdmin.showNotification('Reserva copiada al portapapeles', 'success');
                    
                    // Feedback visual temporal
                    const originalText = $button.html();
                    $button.html('<span class="dashicons dashicons-yes"></span>');
                    setTimeout(function() {
                        $button.html(originalText);
                    }, 1500);
                }).catch(function() {
                    BarowAdmin.showTextModal('Reserva Individual', texto);
                });
            } else {
                BarowAdmin.showTextModal('Reserva Individual', texto);
            }
        },
        
        filterReservas: function() {
            const filtro = $(this).val();
            const $container = $('.barow-reservas-container');
            
            $container.addClass('loading');
            
            $.ajax({
                url: barow_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'barow_get_reservas',
                    filtro: filtro,
                    page: 1,
                    nonce: barow_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        BarowAdmin.updateReservasTable(response.data);
                    }
                    $container.removeClass('loading');
                },
                error: function() {
                    $container.removeClass('loading');
                }
            });
        },
        
        searchClientes: function() {
            const busqueda = $(this).val();
            const $container = $('.barow-clientes-container');
            
            if (busqueda.length < 2 && busqueda.length > 0) return;
            
            $container.addClass('loading');
            
            $.ajax({
                url: barow_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'barow_obtener_clientes',
                    busqueda: busqueda,
                    page: 1,
                    nonce: barow_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        BarowAdmin.updateClientesTable(response.data);
                    }
                    $container.removeClass('loading');
                },
                error: function() {
                    $container.removeClass('loading');
                }
            });
        },
        
        cancelarReserva: function(e) {
            e.preventDefault();
            
            const reservaId = $(this).data('reserva-id');
            const reservaNombre = $(this).data('reserva-nombre');
            
            if (!confirm(`¿Estás seguro de cancelar la reserva de ${reservaNombre}?`)) {
                return;
            }
            
            const $button = $(this);
            $button.prop('disabled', true);
            
            $.ajax({
                url: barow_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'barow_cancelar_reserva',
                    reserva_id: reservaId,
                    nonce: barow_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        BarowAdmin.showNotification('Reserva cancelada correctamente', 'success');
                        $button.closest('tr').addClass('cancelled');
                        $button.html('<span class="dashicons dashicons-dismiss"></span> Cancelada');
                    } else {
                        BarowAdmin.showNotification(response.data.mensaje || 'Error al cancelar', 'error');
                    }
                    $button.prop('disabled', false);
                },
                error: function() {
                    BarowAdmin.showNotification('Error de conexión', 'error');
                    $button.prop('disabled', false);
                }
            });
        },
        
        eliminarReserva: function(e) {
            e.preventDefault();
            
            const reservaId = $(this).data('reserva-id');
            const reservaNombre = $(this).data('reserva-nombre');
            
            if (!confirm(`¿Estás seguro de ELIMINAR PERMANENTEMENTE la reserva de ${reservaNombre}?\n\nEsta acción no se puede deshacer.`)) {
                return;
            }
            
            const $button = $(this);
            const $row = $button.closest('tr');
            
            $button.prop('disabled', true);
            
            $.ajax({
                url: barow_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'barow_eliminar_reserva',
                    reserva_id: reservaId,
                    nonce: barow_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        BarowAdmin.showNotification('Reserva eliminada correctamente', 'success');
                        $row.fadeOut(500, function() {
                            $(this).remove();
                        });
                    } else {
                        BarowAdmin.showNotification(response.data.mensaje || 'Error al eliminar', 'error');
                        $button.prop('disabled', false);
                    }
                },
                error: function() {
                    BarowAdmin.showNotification('Error de conexión', 'error');
                    $button.prop('disabled', false);
                }
            });
        },
        
        showReservaDetails: function(e) {
            e.preventDefault();
            
            const reservaId = $(this).data('reserva-id');
            // Implementar modal de detalles
            console.log('Mostrar detalles de reserva:', reservaId);
        },
        
        updateReservasTable: function(data) {
            // Actualizar tabla de reservas
            const $table = $('.barow-reservas-table tbody');
            $table.empty();
            
            if (data.reservas && data.reservas.length > 0) {
                data.reservas.forEach(function(reserva) {
                    const row = BarowAdmin.createReservaRow(reserva);
                    $table.append(row);
                });
            } else {
                $table.append('<tr><td colspan="6" style="text-align: center; padding: 40px;">No hay reservas para mostrar</td></tr>');
            }
            
            // Actualizar paginación
            BarowAdmin.updatePagination(data.pages, 1);
        },
        
        updateClientesTable: function(data) {
            // Actualizar tabla de clientes
            const $table = $('.barow-clientes-table tbody');
            $table.empty();
            
            if (data.clientes && data.clientes.length > 0) {
                data.clientes.forEach(function(cliente) {
                    const row = BarowAdmin.createClienteRow(cliente);
                    $table.append(row);
                });
            } else {
                $table.append('<tr><td colspan="5" style="text-align: center; padding: 40px;">No hay clientes para mostrar</td></tr>');
            }
        },
        
        createReservaRow: function(reserva) {
            const fecha = new Date(reserva.fecha_reserva).toLocaleDateString('es-ES');
            const estado = reserva.estado === 'cancelada' ? 'cancelled' : 'active';
            const estadoTexto = reserva.estado === 'cancelada' ? 'Cancelada' : 'Activa';
            const estadoIcon = reserva.estado === 'cancelada' ? 'dismiss' : 'yes-alt';
            
            return `
                <tr class="${estado}">
                    <td>
                        <strong>${reserva.nombre_cliente}</strong><br>
                        <small>${reserva.email_cliente}</small>
                    </td>
                    <td>${fecha}</td>
                    <td>${reserva.hora_reserva}</td>
                    <td>${reserva.cantidad_personas}</td>
                    <td>
                        <span class="barow-status ${estado}">
                            <span class="dashicons dashicons-${estadoIcon}"></span>
                            ${estadoTexto}
                        </span>
                    </td>
                    <td>
                        <button class="button button-small barow-view-details" data-reserva-id="${reserva.id}">
                            <span class="dashicons dashicons-visibility"></span>
                        </button>
                        ${reserva.estado !== 'cancelada' ? `
                            <button class="button button-small barow-cancel-reserva" data-reserva-id="${reserva.id}" data-reserva-nombre="${reserva.nombre_cliente}">
                                <span class="dashicons dashicons-dismiss"></span>
                            </button>
                        ` : ''}
                        <button class="button button-small button-link-delete barow-delete-reserva" data-reserva-id="${reserva.id}" data-reserva-nombre="${reserva.nombre_cliente}">
                            <span class="dashicons dashicons-trash"></span>
                        </button>
                    </td>
                </tr>
            `;
        },
        
        createClienteRow: function(cliente) {
            const ultimaReserva = new Date(cliente.ultima_reserva).toLocaleDateString('es-ES');
            
            return `
                <tr>
                    <td>
                        <strong>${cliente.nombre}</strong><br>
                        <small>${cliente.email}</small>
                    </td>
                    <td>${cliente.telefono || 'No proporcionado'}</td>
                    <td>${cliente.total_reservas}</td>
                    <td>${ultimaReserva}</td>
                    <td>
                        <button class="button button-small" onclick="location.href='?page=reserva-mesas&cliente_email=${encodeURIComponent(cliente.email)}'">
                            <span class="dashicons dashicons-visibility"></span>
                            Ver Reservas
                        </button>
                    </td>
                </tr>
            `;
        },
        
        updatePagination: function(totalPages, currentPage) {
            // Actualizar controles de paginación
            const $pagination = $('.barow-pagination');
            $pagination.empty();
            
            if (totalPages > 1) {
                for (let i = 1; i <= totalPages; i++) {
                    const isActive = i === currentPage ? 'current' : '';
                    $pagination.append(`<a href="#" class="page-numbers ${isActive}" data-page="${i}">${i}</a>`);
                }
            }
        },
        
        showTextModal: function(title, text) {
            // Crear modal para mostrar texto
            const modal = `
                <div class="barow-modal-overlay">
                    <div class="barow-modal">
                        <div class="barow-modal-header">
                            <h3>${title}</h3>
                            <button class="barow-modal-close">&times;</button>
                        </div>
                        <div class="barow-modal-body">
                            <textarea readonly style="width: 100%; height: 300px; font-family: monospace;">${text}</textarea>
                        </div>
                        <div class="barow-modal-footer">
                            <button class="button button-primary barow-select-all">Seleccionar Todo</button>
                            <button class="button barow-modal-close">Cerrar</button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modal);
            
            $('.barow-modal-close').on('click', function() {
                $('.barow-modal-overlay').remove();
            });
            
            $('.barow-select-all').on('click', function() {
                $('.barow-modal textarea')[0].select();
            });
        },
        
        showNotification: function(message, type = 'info') {
            // Mostrar notificación
            const icons = {
                success: 'yes-alt',
                error: 'dismiss',
                warning: 'warning',
                info: 'info'
            };
            
            const notification = `
                <div class="barow-notification ${type}" style="position: fixed; top: 32px; right: 20px; z-index: 999999; background: white; border-left: 4px solid #00a32a; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 15px 20px; margin-bottom: 10px; max-width: 300px;">
                    <div style="display: flex; align-items: center;">
                        <span class="dashicons dashicons-${icons[type]}" style="margin-right: 10px;"></span>
                        <span>${message}</span>
                    </div>
                </div>
            `;
            
            $('body').append(notification);
            
            setTimeout(function() {
                $('.barow-notification').fadeOut(500, function() {
                    $(this).remove();
                });
            }, 3000);
        },
        
        loadPage: function(page) {
            // Cargar página con AJAX
            const filtro = $('.barow-filter-select').val() || 'todas';
            
            $.ajax({
                url: barow_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'barow_get_reservas',
                    filtro: filtro,
                    page: page,
                    nonce: barow_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        BarowAdmin.updateReservasTable(response.data);
                    }
                }
            });
        },
        
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func.apply(this, args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    };
    
    // Inicializar cuando el documento esté listo
    $(document).ready(function() {
        BarowAdmin.init();
    });
    
    // Hacer disponible globalmente
    window.BarowAdmin = BarowAdmin;
    
})(jQuery);

// CSS adicional para mejoras visuales
const additionalCSS = `
<style>
.barow-status.active {
    color: #00a32a;
    font-weight: bold;
}

.barow-status.cancelled {
    color: #d63638;
    font-weight: bold;
}

.barow-notification.success {
    border-left-color: #00a32a !important;
}

.barow-notification.error {
    border-left-color: #d63638 !important;
}

.barow-notification.warning {
    border-left-color: #dba617 !important;
}

.loading {
    opacity: 0.6;
    pointer-events: none;
}

.spin {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.barow-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 999999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.barow-modal {
    background: white;
    border-radius: 8px;
    max-width: 600px;
    width: 90%;
    max-height: 80vh;
    overflow: hidden;
}

.barow-modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.barow-modal-body {
    padding: 20px;
}

.barow-modal-footer {
    padding: 20px;
    border-top: 1px solid #ddd;
    text-align: right;
}

.barow-modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
}
</style>
`;

// Agregar CSS al documento
if (typeof document !== 'undefined') {
    document.head.insertAdjacentHTML('beforeend', additionalCSS);
}
