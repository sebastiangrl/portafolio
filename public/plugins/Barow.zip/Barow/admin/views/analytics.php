<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'reservas';

// Verificar que la tabla existe
$table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name));
if (!$table_exists) {
    echo '<div class="wrap"><h1><span class="dashicons dashicons-chart-area"></span> Analytics</h1><div class="notice notice-error"><p>Error: La tabla de reservas no existe. Por favor, reactiva el plugin.</p></div></div>';
    return;
}

// Obtener datos para analytics
try {
    $total_reservas = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE estado != 'cancelada'") ?: 0;
    
    $reservas_hoy = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE fecha_reserva = %s AND estado != 'cancelada'",
        date('Y-m-d')
    )) ?: 0;
    
    $reservas_mes = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE MONTH(fecha_reserva) = %d AND YEAR(fecha_reserva) = %d AND estado != 'cancelada'",
        date('n'), date('Y')
    )) ?: 0;

    // Promedio de personas por reserva
    $avg_personas = $wpdb->get_var("SELECT AVG(cantidad_personas) FROM $table_name WHERE estado != 'cancelada'") ?: 0;
    
    $total_personas_mes = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(cantidad_personas) FROM $table_name WHERE MONTH(fecha_reserva) = %d AND YEAR(fecha_reserva) = %d AND estado != 'cancelada'",
        date('n'), date('Y')
    )) ?: 0;

    // Reservas por estado
    $activas = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE estado IN ('activa', 'confirmada', 'pendiente')") ?: 0;
    $canceladas = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE estado = 'cancelada'") ?: 0;
    $pasadas = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE estado = 'pasada'") ?: 0;

    // Total de clientes únicos
    $total_clientes = $wpdb->get_var("SELECT COUNT(DISTINCT email_cliente) FROM $table_name") ?: 0;

    // Top 10 clientes más frecuentes
    $top_clientes = $wpdb->get_results("
        SELECT nombre_cliente, email_cliente, COUNT(*) as total_reservas, SUM(cantidad_personas) as total_personas
        FROM $table_name 
        WHERE estado != 'cancelada' 
        GROUP BY email_cliente 
        ORDER BY total_reservas DESC 
        LIMIT 10
    ") ?: array();

    // Reservas por día de la semana
    $reservas_por_dia = $wpdb->get_results("
        SELECT 
            DAYOFWEEK(fecha_reserva) as dia_semana,
            COUNT(*) as total
        FROM $table_name 
        WHERE estado != 'cancelada'
        GROUP BY DAYOFWEEK(fecha_reserva)
        ORDER BY dia_semana
    ") ?: array();

    // Horarios más populares
    $horarios_populares = $wpdb->get_results("
        SELECT 
            hora_reserva,
            COUNT(*) as total,
            AVG(cantidad_personas) as avg_personas
        FROM $table_name 
        WHERE estado != 'cancelada'
        GROUP BY hora_reserva
        ORDER BY total DESC
        LIMIT 8
    ") ?: array();

    // Tendencia últimos 30 días
    $tendencia_diaria = $wpdb->get_results("
        SELECT 
            DATE(fecha_reserva) as fecha,
            COUNT(*) as total_reservas,
            SUM(cantidad_personas) as total_personas
        FROM $table_name 
        WHERE fecha_reserva >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        AND estado != 'cancelada'
        GROUP BY DATE(fecha_reserva)
        ORDER BY fecha DESC
    ") ?: array();

    // Reservas por mes (últimos 12 meses)
    $reservas_por_mes_detalle = $wpdb->get_results("
        SELECT 
            DATE_FORMAT(fecha_reserva, '%Y-%m') as mes,
            COUNT(*) as total_reservas,
            SUM(cantidad_personas) as total_personas,
            COUNT(DISTINCT email_cliente) as clientes_unicos
        FROM $table_name 
        WHERE fecha_reserva >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        AND estado != 'cancelada'
        GROUP BY DATE_FORMAT(fecha_reserva, '%Y-%m')
        ORDER BY mes DESC
    ") ?: array();

    // Tasa de cancelación
    $tasa_cancelacion = $wpdb->get_var("
        SELECT (COUNT(CASE WHEN estado = 'cancelada' THEN 1 END) * 100.0 / COUNT(*)) 
        FROM $table_name
    ") ?: 0;

} catch (Exception $e) {
    wp_die('Error al cargar los datos de analytics: ' . esc_html($e->getMessage()));
}

// Función para obtener nombre del día
function obtener_nombre_dia($numero) {
    $dias = array(1 => 'Domingo', 2 => 'Lunes', 3 => 'Martes', 4 => 'Miércoles', 5 => 'Jueves', 6 => 'Viernes', 7 => 'Sábado');
    return isset($dias[$numero]) ? $dias[$numero] : 'Desconocido';
}

// Función para obtener color del día
function obtener_color_dia_analytics($numero) {
    $colores = array(
        1 => '#e74c3c', // Domingo
        2 => '#3498db', // Lunes
        3 => '#2ecc71', // Martes
        4 => '#f39c12', // Miércoles
        5 => '#9b59b6', // Jueves
        6 => '#1abc9c', // Viernes
        7 => '#e67e22'  // Sábado
    );
    return isset($colores[$numero]) ? $colores[$numero] : '#95a5a6';
}
?>

<div class="barow-admin">
    <div class="barow-admin-header">
        <h1>
            <span class="dashicons dashicons-chart-line"></span>
            Analytics y Estadisticas
        </h1>
        <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 16px;">Analisis completo del rendimiento de tu restaurante</p>
    </div>

    <!-- Estadisticas principales -->
    <div class="barow-stats-grid">
        <div class="barow-stat-card">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-calendar-alt"></span>
                <h3 class="barow-stat-title">Reservas Hoy</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($reservas_hoy); ?></div>
            <p class="barow-stat-subtitle">Activas para hoy</p>
        </div>
        
        <div class="barow-stat-card success">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-calendar"></span>
                <h3 class="barow-stat-title">Este Mes</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($reservas_mes); ?></div>
            <p class="barow-stat-subtitle"><?php echo number_format($total_personas_mes); ?> personas atendidas</p>
        </div>
        
        <div class="barow-stat-card warning">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-groups"></span>
                <h3 class="barow-stat-title">Promedio Personas</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($avg_personas, 1); ?></div>
            <p class="barow-stat-subtitle">Por reserva</p>
        </div>
        
        <div class="barow-stat-card error">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-admin-users"></span>
                <h3 class="barow-stat-title">Clientes Unicos</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($total_clientes); ?></div>
            <p class="barow-stat-subtitle">Base de datos total</p>
        </div>
    </div>

    <!-- Graficos principales -->
    <div class="barow-analytics-grid">
        <!-- Horarios más populares -->
        <div class="barow-chart-container">
            <div class="barow-chart-header">
                <h3>
                    <span class="dashicons dashicons-clock"></span>
                    Horarios Más Populares
                </h3>
            </div>
            <div class="barow-horizontal-bars">
                <?php if (!empty($horarios_populares) && is_array($horarios_populares)): ?>
                    <?php 
                    $totales = array_column($horarios_populares, 'total');
                    $max_horario = !empty($totales) ? max($totales) : 1;
                    foreach ($horarios_populares as $horario): 
                        $ancho = $max_horario > 0 ? ($horario->total / $max_horario) * 100 : 0;
                    ?>
                        <div class="barow-horizontal-bar">
                            <div class="barow-bar-time"><?php echo esc_html($horario->hora_reserva); ?></div>
                            <div class="barow-bar-container">
                                <div class="barow-bar-fill" style="width: <?php echo $ancho; ?>%;"></div>
                                <div class="barow-bar-number"><?php echo $horario->total; ?> reservas</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="barow-no-data">No hay datos disponibles</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Reservas por día de la semana -->
        <div class="barow-chart-container">
            <div class="barow-chart-header">
                <h3>
                    <span class="dashicons dashicons-calendar"></span>
                    Popularidad por Día
                </h3>
            </div>
            <div class="barow-bar-chart">
                <?php if (!empty($reservas_por_dia) && is_array($reservas_por_dia)): ?>
                    <?php 
                    $totales_dia = array_column($reservas_por_dia, 'total');
                    $max_dia = !empty($totales_dia) ? max($totales_dia) : 1;
                    foreach ($reservas_por_dia as $dia): 
                        // Filtrar días desconocidos
                        $nombre_dia = obtener_nombre_dia($dia->dia_semana);
                        if ($nombre_dia === 'Desconocido') continue;
                        
                        $altura = $max_dia > 0 ? ($dia->total / $max_dia) * 100 : 0;
                        $color = obtener_color_dia_analytics($dia->dia_semana);
                    ?>
                        <div class="barow-bar-item">
                            <div class="barow-bar" style="height: <?php echo max($altura, 5); ?>%; background: <?php echo $color; ?>;">
                                <span class="barow-bar-value"><?php echo $dia->total; ?></span>
                            </div>
                            <span class="barow-bar-label"><?php echo $nombre_dia; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="barow-no-data">No hay datos disponibles</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Tendencia y métricas -->
    <div class="barow-analytics-grid">
        <!-- Tendencia últimos 30 días -->
        <div class="barow-chart-container">
            <div class="barow-chart-header">
                <h3>
                    <span class="dashicons dashicons-chart-area"></span>
                    Tendencia Últimos 30 Días
                </h3>
            </div>
                        <div class="barow-line-chart">
                <?php if (!empty($tendencia_diaria) && is_array($tendencia_diaria)): ?>
                    <?php 
                    $totales_tendencia = array_column($tendencia_diaria, 'total_reservas');
                    $max_tendencia = !empty($totales_tendencia) ? max($totales_tendencia) : 1;
                    $count = 0;
                    foreach (array_reverse($tendencia_diaria) as $dia): 
                        if ($count++ >= 15) break; // Mostrar solo últimos 15 días
                        $altura = $max_tendencia > 0 ? ($dia->total_reservas / $max_tendencia) * 100 : 0;
                    ?>
                        <div class="barow-line-point">
                            <div class="barow-point" style="height: <?php echo max($altura, 5); ?>%;">
                                <span class="barow-point-value"><?php echo $dia->total_reservas; ?></span>
                            </div>
                            <span class="barow-point-label"><?php 
                            $fecha_timestamp = strtotime($dia->fecha);
                            echo $fecha_timestamp ? date('d/m', $fecha_timestamp) : substr($dia->fecha, -5);
                            ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="barow-no-data">No hay datos disponibles</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Métricas de Eficiencia -->
        <div class="barow-chart-container">
            <div class="barow-chart-header">
                <h3>
                    <span class="dashicons dashicons-chart-bar"></span>
                    Métricas de Eficiencia
                </h3>
            </div>
            <div class="barow-efficiency-metrics">
                <div class="barow-metric-item">
                    <div class="barow-metric-icon">
                        <span class="dashicons dashicons-dismiss" style="color: var(--barow-error);"></span>
                    </div>
                    <div class="barow-metric-content">
                        <span class="barow-metric-value"><?php echo number_format($tasa_cancelacion, 1); ?>%</span>
                        <span class="barow-metric-label">Tasa de Cancelación</span>
                    </div>
                </div>

                <div class="barow-metric-item">
                    <div class="barow-metric-icon">
                        <span class="dashicons dashicons-groups" style="color: var(--barow-success);"></span>
                    </div>
                    <div class="barow-metric-content">
                        <span class="barow-metric-value"><?php echo number_format($avg_personas, 1); ?></span>
                        <span class="barow-metric-label">Personas por Mesa</span>
                    </div>
                </div>

                <div class="barow-metric-item">
                    <div class="barow-metric-icon">
                        <span class="dashicons dashicons-admin-users" style="color: var(--barow-warning);"></span>
                    </div>
                    <div class="barow-metric-content">
                        <span class="barow-metric-value"><?php echo $total_clientes > 0 ? number_format($total_reservas / $total_clientes, 1) : '0'; ?></span>
                        <span class="barow-metric-label">Reservas por Cliente</span>
                    </div>
                </div>

                <div class="barow-metric-item">
                    <div class="barow-metric-icon">
                        <span class="dashicons dashicons-calendar-alt" style="color: var(--barow-primary);"></span>
                    </div>
                    <div class="barow-metric-content">
                        <span class="barow-metric-value"><?php echo $reservas_mes > 0 ? number_format($total_personas_mes / $reservas_mes, 1) : '0'; ?></span>
                        <span class="barow-metric-label">Promedio Mensual</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tablas de datos -->
    <div class="barow-analytics-grid">
        <!-- Top clientes -->
        <div class="barow-table-container">
            <div class="barow-table-header">
                <h3 class="barow-table-title">
                    <span class="dashicons dashicons-star-filled"></span>
                    Top Clientes Frecuentes
                </h3>
            </div>
            <?php if (!empty($top_clientes) && is_array($top_clientes)): ?>
                <table class="barow-table">
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th>Reservas</th>
                            <th>Personas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($top_clientes as $index => $cliente): ?>
                            <tr>
                                <td>
                                    <div class="barow-client-ranking">
                                        <span class="barow-ranking-number">#<?php echo $index + 1; ?></span>
                                        <div>
                                            <strong><?php echo esc_html(isset($cliente->nombre_cliente) ? $cliente->nombre_cliente : 'Sin nombre'); ?></strong>
                                            <div style="font-size: 12px; color: #666;"><?php echo esc_html(isset($cliente->email_cliente) ? $cliente->email_cliente : 'Sin email'); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="barow-badge barow-badge-frecuente"><?php echo isset($cliente->total_reservas) ? $cliente->total_reservas : 0; ?></span>
                                </td>
                                <td>
                                    <span class="barow-badge barow-badge-people"><?php echo isset($cliente->total_personas) ? $cliente->total_personas : 0; ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="barow-no-results">
                    <div class="barow-no-results-icon">
                        <span class="dashicons dashicons-star-filled"></span>
                    </div>
                    <h3>No hay datos disponibles</h3>
                    <p>Los clientes aparecerán aquí cuando realicen reservas.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Tendencia mensual detallada -->
        <div class="barow-table-container">
            <div class="barow-table-header">
                <h3 class="barow-table-title">
                    <span class="dashicons dashicons-chart-line"></span>
                    Evolución Mensual (Últimos 12 Meses)
                </h3>
            </div>
            <?php if (!empty($reservas_por_mes_detalle) && is_array($reservas_por_mes_detalle)): ?>
                <table class="barow-table">
                    <thead>
                        <tr>
                            <th>Mes</th>
                            <th>Reservas</th>
                            <th>Personas</th>
                            <th>Clientes Únicos</th>
                            <th>Promedio por Reserva</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservas_por_mes_detalle as $mes): ?>
                            <tr>
                                <td>
                                    <?php 
                                    // Formato más seguro para mostrar el mes
                                    $mes_parts = explode('-', $mes->mes);
                                    if (count($mes_parts) == 2) {
                                        $year = $mes_parts[0];
                                        $month = $mes_parts[1];
                                        $month_names = array('01' => 'Ene', '02' => 'Feb', '03' => 'Mar', '04' => 'Abr', '05' => 'May', '06' => 'Jun', '07' => 'Jul', '08' => 'Ago', '09' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dic');
                                        echo (isset($month_names[$month]) ? $month_names[$month] : $month) . ' ' . $year;
                                    } else {
                                        echo esc_html($mes->mes);
                                    }
                                    ?>
                                </td>
                                <td><span class="barow-badge barow-badge-primary"><?php echo number_format(isset($mes->total_reservas) ? $mes->total_reservas : 0); ?></span></td>
                                <td><span class="barow-badge barow-badge-people"><?php echo number_format(isset($mes->total_personas) ? $mes->total_personas : 0); ?></span></td>
                                <td><span class="barow-badge barow-badge-nuevo"><?php echo number_format(isset($mes->clientes_unicos) ? $mes->clientes_unicos : 0); ?></span></td>
                                <td>
                                    <strong><?php 
                                    $total_reservas = isset($mes->total_reservas) ? $mes->total_reservas : 0;
                                    $total_personas = isset($mes->total_personas) ? $mes->total_personas : 0;
                                    echo $total_reservas > 0 ? number_format($total_personas / $total_reservas, 1) : '0'; 
                                    ?></strong>
                                    personas
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="barow-no-results">
                    <div class="barow-no-results-icon">
                        <span class="dashicons dashicons-chart-line"></span>
                    </div>
                    <h3>No hay datos históricos</h3>
                    <p>Los datos mensuales aparecerán aquí a medida que se acumulen reservas.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
