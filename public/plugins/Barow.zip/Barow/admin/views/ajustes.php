<?php
if (!defined('ABSPATH')) {
    exit;
}

function reserva_mesas_pagina_ajustes() {
    // Añadir estilos directamente aquí
    ?>
    <style>
        .ajustes-wrapper {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
            background: #f1f1f1;
            min-height: 100vh;
        }

        .ajustes-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
        }

        .ajustes-header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        .ajustes-header h1 .dashicons {
            font-size: 40px;
            line-height: 1;
        }

        .ajustes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .ajustes-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .ajustes-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
        }

        .ajustes-card h2 {
            margin: 0;
            padding: 25px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-bottom: 1px solid #dee2e6;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.3em;
            font-weight: 600;
        }

        .ajustes-card h2 .dashicons {
            color: #667eea;
            font-size: 1.2em;
        }

        .card-content {
            padding: 25px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
            font-size: 0.95em;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="number"],
        .form-group input[type="time"],
        .form-group select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            background-color: #fff;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            outline: none;
            background-color: #fbfcff;
        }

        .form-group input[type="date"] {
            width: auto;
            padding: 12px 16px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .form-group input[type="checkbox"] {
            margin-right: 10px;
            transform: scale(1.2);
        }

        .dias-semana {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 12px;
        }

        .dia-checkbox {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border: 2px solid #e9ecef;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .dia-checkbox:hover {
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            border-color: #667eea;
            transform: translateY(-2px);
        }

        .dia-checkbox input:checked + span {
            color: #667eea;
            font-weight: 600;
        }

        .media-preview {
            margin-top: 15px;
            max-width: 200px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .button-upload {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 10px;
            padding: 10px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white !important;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            text-decoration: none;
        }

        .button-upload:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
            color: white !important;
        }

        .button-secondary-custom {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            color: white !important;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            font-size: 13px;
            text-decoration: none;
        }

        .button-secondary-custom:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.4);
            color: white !important;
        }

        .button-save {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            font-size: 16px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .button-save:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .ajustes-footer {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            text-align: center;
        }

        .tooltip {
            position: relative;
            display: inline-block;
            margin-left: 8px;
            color: #667eea;
            cursor: help;
        }

        .tooltip .tooltiptext {
            visibility: hidden;
            width: 250px;
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            text-align: center;
            border-radius: 8px;
            padding: 12px;
            position: absolute;
            z-index: 1000;
            bottom: 125%;
            left: 50%;
            margin-left: -125px;
            opacity: 0;
            transition: all 0.3s ease;
            font-size: 13px;
            line-height: 1.4;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }

        .tooltip .tooltiptext::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #2c3e50 transparent transparent transparent;
        }

        .tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
            transform: translateY(-5px);
        }

        .notice {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            border: 1px solid #b8daff;
            border-radius: 8px;
            padding: 15px 20px;
            margin: 20px 0;
            color: #155724;
            font-weight: 500;
        }

        @media (max-width: 768px) {
            .ajustes-wrapper {
                padding: 15px;
            }
            
            .ajustes-grid {
                grid-template-columns: 1fr;
            }
            
            .dias-semana {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <?php
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_ajustes'])) {
        if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'guardar_ajustes_reservas')) {
            // Ajustes de capacidad y horario
            $max_personas = isset($_POST['max_personas']) ? intval($_POST['max_personas']) : 10;
            $hora_inicio = sanitize_text_field($_POST['hora_inicio']);
            $hora_fin = sanitize_text_field($_POST['hora_fin']);

            // Validaciones
            if ($max_personas >= 1 && $max_personas <= 20) {
                update_option('reserva_mesas_max_personas', $max_personas);
            }

            if (strtotime($hora_inicio) < strtotime($hora_fin)) {
                update_option('reserva_mesas_hora_inicio', $hora_inicio);
                update_option('reserva_mesas_hora_fin', $hora_fin);
            }

            // Información de la empresa
            update_option('reserva_mesas_nombre_empresa', sanitize_text_field($_POST['nombre_empresa']));
            update_option('reserva_mesas_correo_notificaciones', sanitize_email($_POST['correo_notificaciones']));
            update_option('reserva_mesas_logo_empresa', esc_url_raw($_POST['logo_empresa']));

            // Días bloqueados y cerrados
            $dias_bloqueados = isset($_POST['dias_bloqueados']) ? array_map('sanitize_text_field', $_POST['dias_bloqueados']) : [];
            $dias_cerrados = isset($_POST['dias_cerrados']) ? array_map('sanitize_text_field', $_POST['dias_cerrados']) : [];

            update_option('reserva_mesas_dias_bloqueados', $dias_bloqueados);
            update_option('reserva_mesas_dias_cerrados', $dias_cerrados);

            echo "<div class='notice notice-success'><p>🎉 ¡Configuración actualizada correctamente!</p></div>";
        }
    }

    // Obtener valores actuales
    $max_personas = get_option('reserva_mesas_max_personas', 10);
    $hora_inicio = get_option('reserva_mesas_hora_inicio', '17:00');
    $hora_fin = get_option('reserva_mesas_hora_fin', '23:00');
    $nombre_empresa = get_option('reserva_mesas_nombre_empresa', '');
    $correo_notificaciones = get_option('reserva_mesas_correo_notificaciones', get_option('admin_email'));
    $logo_empresa = get_option('reserva_mesas_logo_empresa', '');
    $dias_bloqueados = get_option('reserva_mesas_dias_bloqueados', []);
    $dias_cerrados = get_option('reserva_mesas_dias_cerrados', []);

    ?>
    <div class="ajustes-wrapper">
        <div class="ajustes-header">
            <h1>
                <span class="dashicons dashicons-admin-settings"></span>
                Configuración del Sistema Barow
            </h1>
        </div>

        <form method="POST">
            <?php wp_nonce_field('guardar_ajustes_reservas'); ?>
            
            <div class="ajustes-grid">
                <!-- Información del Sistema -->
                <div class="ajustes-card" style="grid-column: 1 / -1; background: linear-gradient(135deg, #e8f5e8 0%, #f0f8ff 100%); border-left: 4px solid #4CAF50;">
                    <h2>
                        <span class="dashicons dashicons-info"></span>
                        Sistema de Reservas para Restaurantes
                    </h2>
                    
                    <div class="card-content">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; font-size: 14px;">
                            <div style="display: flex; align-items: flex-start; gap: 10px;">
                                <span style="color: #4CAF50; font-size: 18px;">✅</span>
                                <div>
                                    <strong>Múltiples reservas simultáneas</strong><br>
                                    <span style="color: #666;">El sistema permite tantas reservas como necesites a la misma hora</span>
                                </div>
                            </div>
                            <div style="display: flex; align-items: flex-start; gap: 10px;">
                                <span style="color: #4CAF50; font-size: 18px;">✅</span>
                                <div>
                                    <strong>Sin límites de capacidad global</strong><br>
                                    <span style="color: #666;">Solo controlas el máximo por grupo, no la capacidad total</span>
                                </div>
                            </div>
                            <div style="display: flex; align-items: flex-start; gap: 10px;">
                                <span style="color: #4CAF50; font-size: 18px;">✅</span>
                                <div>
                                    <strong>Horarios flexibles</strong><br>
                                    <span style="color: #666;">Reservas disponibles cada 15 minutos durante todo el horario</span>
                                </div>
                            </div>
                            <div style="display: flex; align-items: flex-start; gap: 10px;">
                                <span style="color: #2196F3; font-size: 18px;">💡</span>
                                <div>
                                    <strong>Ideal para restaurantes</strong><br>
                                    <span style="color: #666;">Diseñado específicamente para el flujo de trabajo de restaurantes y bares</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Configuración de Capacidad -->
                <div class="ajustes-card">
                    <h2>
                        <span class="dashicons dashicons-groups"></span>
                        Capacidad y Horarios
                    </h2>
                    
                    <div class="card-content">
                        <div class="form-group">
                            <label for="max_personas">
                                Máximo de personas por grupo
                                <span class="tooltip">
                                    <span class="dashicons dashicons-editor-help"></span>
                                    <span class="tooltiptext">Define el número máximo de personas permitidas por reserva individual. El restaurante puede tener múltiples reservas simultáneas.</span>
                                </span>
                            </label>
                            <input type="number" 
                                   id="max_personas" 
                                   name="max_personas" 
                                   value="<?php echo esc_attr($max_personas); ?>" 
                                   min="1" 
                                   max="20" 
                                   required>
                            <p style="font-size: 12px; color: #666; margin-top: 5px;">
                                ℹ️ <strong>Nota:</strong> Este sistema permite múltiples reservas al mismo tiempo. No hay límite de reservas simultáneas - ideal para restaurantes.
                            </p>
                        </div>

                        <div class="form-group">
                            <label for="hora_inicio">Hora de inicio de reservas</label>
                            <input type="time" 
                                   id="hora_inicio" 
                                   name="hora_inicio" 
                                   value="<?php echo esc_attr($hora_inicio); ?>" 
                                   required>
                            <p style="font-size: 12px; color: #666; margin-top: 5px;">
                                🕐 Hora de apertura del restaurante para reservas
                            </p>
                        </div>

                        <div class="form-group">
                            <label for="hora_fin">Hora de fin de reservas</label>
                            <input type="time" 
                                   id="hora_fin" 
                                   name="hora_fin" 
                                   value="<?php echo esc_attr($hora_fin); ?>" 
                                   required>
                            <p style="font-size: 12px; color: #666; margin-top: 5px;">
                                🕙 Última hora disponible para hacer reservas
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Información de la Empresa -->
                <div class="ajustes-card">
                    <h2>
                        <span class="dashicons dashicons-store"></span>
                        Información de la Empresa
                    </h2>
                    
                    <div class="card-content">
                        <div class="form-group">
                            <label for="nombre_empresa">Nombre de la empresa</label>
                            <input type="text" 
                                   id="nombre_empresa" 
                                   name="nombre_empresa" 
                                   value="<?php echo esc_attr($nombre_empresa); ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="correo_notificaciones">Correo para notificaciones</label>
                            <input type="email" 
                                   id="correo_notificaciones" 
                                   name="correo_notificaciones" 
                                   value="<?php echo esc_attr($correo_notificaciones); ?>" 
                                   required>
                        </div>

                        <div class="form-group">
                            <label for="logo_empresa">Logo de la empresa</label>
                            <input type="text" 
                                   id="logo_empresa" 
                                   name="logo_empresa" 
                                   value="<?php echo esc_url($logo_empresa); ?>" 
                                   class="regular-text">
                            <button type="button" 
                                    class="button-secondary-custom" 
                                    id="upload_logo_button">
                                <span class="dashicons dashicons-upload"></span>
                                Seleccionar Logo
                            </button>
                            <?php if ($logo_empresa): ?>
                                <img src="<?php echo esc_url($logo_empresa); ?>" 
                                     alt="Logo de la empresa" 
                                     class="media-preview">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Gestión de Días -->
                <div class="ajustes-card">
                    <h2>
                        <span class="dashicons dashicons-calendar-alt"></span>
                        Gestión de Días
                    </h2>
                    
                    <div class="card-content">
                        <div class="form-group">
                            <label>Días específicos bloqueados</label>
                            <input type="date" 
                                   name="dias_bloqueados[]" 
                                   multiple 
                                   value="<?php echo implode(',', $dias_bloqueados); ?>">
                        </div>

                        <div class="form-group">
                            <label>Días de la semana cerrados</label>
                            <div class="dias-semana">
                                <?php
                                $dias = array(
                                    'monday' => 'Lunes',
                                    'tuesday' => 'Martes',
                                    'wednesday' => 'Miércoles',
                                    'thursday' => 'Jueves',
                                    'friday' => 'Viernes',
                                    'saturday' => 'Sábado',
                                    'sunday' => 'Domingo'
                                );

                                foreach ($dias as $valor => $etiqueta): ?>
                                    <label class="dia-checkbox">
                                        <input type="checkbox" 
                                               name="dias_cerrados[]" 
                                               value="<?php echo $valor; ?>" 
                                               <?php echo in_array($valor, $dias_cerrados) ? 'checked' : ''; ?>>
                                        <span><?php echo $etiqueta; ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="ajustes-footer">
                <button type="submit" 
                        name="guardar_ajustes" 
                        class="button-save">
                    <span class="dashicons dashicons-saved"></span>
                    Guardar Cambios
                </button>
            </div>
        </form>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Manejo del selector de medios para el logo
        var mediaUploader;
        
        $('#upload_logo_button').click(function(e) {
            e.preventDefault();

            if (mediaUploader) {
                mediaUploader.open();
                return;
            }

            mediaUploader = wp.media({
                title: 'Seleccionar Logo',
                button: {
                    text: 'Usar este logo'
                },
                multiple: false
            });

            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#logo_empresa').val(attachment.url);
                
                // Actualizar la vista previa
                if ($('.media-preview').length) {
                    $('.media-preview').attr('src', attachment.url);
                } else {
                    $('<img>', {
                        src: attachment.url,
                        class: 'media-preview'
                    }).insertAfter('#upload_logo_button');
                }
            });

            mediaUploader.open();
        });

        // Validación del horario
        $('form').on('submit', function(e) {
            var horaInicio = $('#hora_inicio').val();
            var horaFin = $('#hora_fin').val();
            
            if (horaInicio >= horaFin) {
                e.preventDefault();
                alert('La hora de inicio debe ser anterior a la hora de fin.');
                return false;
            }
        });

        // Mejorar la selección de días bloqueados
        var diasBloqueados = $('input[name="dias_bloqueados[]"]');

        // Función para añadir un nuevo campo de fecha
        function agregarCampoDeFecha() {
            var nuevoInput = $('<input>', {
                type: 'date',
                name: 'dias_bloqueados[]',
                css: {
                    'margin-bottom': '10px'
                }
            });
            diasBloqueados.parent().append(nuevoInput);
        }

        // Añadir botón para agregar más fechas
        $('<button>', {
            html: '<span class="dashicons dashicons-plus-alt" style="font-size: 16px; line-height: 1;"></span> Añadir más fechas',
            type: 'button',
            class: 'button-secondary-custom',
            css: {
                'margin-left': '10px'
            },
            click: agregarCampoDeFecha
        }).insertAfter(diasBloqueados);

        // Animaciones suaves para cambios de estado
        $('.dia-checkbox').on('change', 'input[type="checkbox"]', function() {
            $(this).closest('.dia-checkbox').toggleClass('checked');
        });

        // Tooltips interactivos
        $('.tooltip').each(function() {
            var tooltip = $(this);
            var timeoutId;

            tooltip.on('mouseenter', function() {
                timeoutId = setTimeout(function() {
                    tooltip.find('.tooltiptext').addClass('active');
                }, 200);
            }).on('mouseleave', function() {
                clearTimeout(timeoutId);
                tooltip.find('.tooltiptext').removeClass('active');
            });
        });

        // Validación de campos numéricos
        $('#max_personas').on('input', function() {
            var val = $(this).val();
            var min = parseInt($(this).attr('min'));
            var max = parseInt($(this).attr('max'));

            if (val < min) $(this).val(min);
            if (val > max) $(this).val(max);
        });

        // Preview del logo en tiempo real
        $('#logo_empresa').on('input', function() {
            var url = $(this).val();
            if (url) {
                if ($('.media-preview').length) {
                    $('.media-preview').attr('src', url);
                } else {
                    $('<img>', {
                        src: url,
                        class: 'media-preview'
                    }).insertAfter('#upload_logo_button');
                }
            } else {
                $('.media-preview').remove();
            }
        });
    });
    </script>
    <?php
}

// Función para encolar los scripts necesarios
function reserva_mesas_enqueue_media() {
    if (is_admin()) {
        wp_enqueue_media();
    }
}
add_action('admin_enqueue_scripts', 'reserva_mesas_enqueue_media');
?>