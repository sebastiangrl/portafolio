<?php
if (!defined('ABSPATH')) {
    exit;
}

// Cargar configuración existente (compatibilidad con el sistema anterior)
$personalizacion = get_option('barow_personalizacion', array());

// Valores por defecto con compatibilidad del sistema anterior
$borde_color = !empty($personalizacion['borde_color']) ? $personalizacion['borde_color'] : get_option('reserva_mesas_borde_color', '#3498db');
$bg_color = !empty($personalizacion['bg_color']) ? $personalizacion['bg_color'] : get_option('reserva_mesas_bg_color', '#3498db');
$btn_font_color = !empty($personalizacion['btn_font_color']) ? $personalizacion['btn_font_color'] : get_option('reserva_mesas_btn_font_color', '#ffffff');
$label_font_color = !empty($personalizacion['label_font_color']) ? $personalizacion['label_font_color'] : get_option('reserva_mesas_label_font_color', '#333333');
$borde_radius = !empty($personalizacion['borde_radius']) ? $personalizacion['borde_radius'] : get_option('reserva_mesas_borde_radius', '5');
$popup_imagen_url = !empty($personalizacion['popup_imagen_url']) ? $personalizacion['popup_imagen_url'] : get_option('reserva_mesas_popup_imagen_url', '');
$popup_imagen_width = !empty($personalizacion['popup_imagen_width']) ? $personalizacion['popup_imagen_width'] : get_option('reserva_mesas_popup_imagen_width', '80');

// Nuevos campos solo para diseño
$input_bg_color = !empty($personalizacion['input_bg_color']) ? $personalizacion['input_bg_color'] : '#ffffff';
$input_text_color = !empty($personalizacion['input_text_color']) ? $personalizacion['input_text_color'] : '#333333';
$form_bg_color = !empty($personalizacion['form_bg_color']) ? $personalizacion['form_bg_color'] : '#ffffff';
$titulo_formulario = !empty($personalizacion['titulo_formulario']) ? $personalizacion['titulo_formulario'] : 'Reserva tu Mesa';
$texto_boton = !empty($personalizacion['texto_boton']) ? $personalizacion['texto_boton'] : 'Reservar Ahora';

// Procesar formulario
if (isset($_POST['barow_save_personalization']) && wp_verify_nonce($_POST['_wpnonce'], 'barow_personalization_nonce')) {
    $nueva_personalizacion = array(
        'borde_color' => sanitize_hex_color($_POST['borde_color']),
        'bg_color' => sanitize_hex_color($_POST['bg_color']),
        'btn_font_color' => sanitize_hex_color($_POST['btn_font_color']),
        'label_font_color' => sanitize_hex_color($_POST['label_font_color']),
        'input_bg_color' => sanitize_hex_color($_POST['input_bg_color']),
        'input_text_color' => sanitize_hex_color($_POST['input_text_color']),
        'form_bg_color' => sanitize_hex_color($_POST['form_bg_color']),
        'borde_radius' => intval($_POST['borde_radius']),
        'popup_imagen_url' => esc_url_raw($_POST['popup_imagen_url']),
        'popup_imagen_width' => intval($_POST['popup_imagen_width']),
        'titulo_formulario' => sanitize_text_field($_POST['titulo_formulario']),
        'texto_boton' => sanitize_text_field($_POST['texto_boton'])
    );
    
    // Guardar en el nuevo sistema
    update_option('barow_personalizacion', $nueva_personalizacion);
    
    // Mantener compatibilidad con el sistema anterior
    update_option('reserva_mesas_borde_color', $nueva_personalizacion['borde_color']);
    update_option('reserva_mesas_bg_color', $nueva_personalizacion['bg_color']);
    update_option('reserva_mesas_btn_font_color', $nueva_personalizacion['btn_font_color']);
    update_option('reserva_mesas_label_font_color', $nueva_personalizacion['label_font_color']);
    update_option('reserva_mesas_borde_radius', $nueva_personalizacion['borde_radius']);
    update_option('reserva_mesas_popup_imagen_url', $nueva_personalizacion['popup_imagen_url']);
    update_option('reserva_mesas_popup_imagen_width', $nueva_personalizacion['popup_imagen_width']);
    
    // Actualizar variables para mostrar cambios
    extract($nueva_personalizacion);
    
    echo '<div class="notice notice-success is-dismissible"><p><strong>¡Personalización guardada exitosamente!</strong> Los cambios se aplicarán en el formulario de reservas.</p></div>';
}
?>

<style>
.barow-admin {
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
    background: #f1f1f1;
    min-height: 100vh;
}

.barow-admin-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    margin-bottom: 30px;
    text-align: center;
}

.barow-admin-header h1 {
    margin: 0 0 10px 0;
    font-size: 2.5em;
    font-weight: 300;
    text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
}

.barow-admin-header h1 .dashicons {
    font-size: 40px;
    line-height: 1;
}

.barow-sections-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.barow-section-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    overflow: hidden;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.barow-section-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.12);
}

.barow-section-card h2 {
    margin: 0;
    padding: 25px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-bottom: 1px solid #dee2e6;
    color: #2c3e50;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 1.3em;
    font-weight: 600;
}

.barow-section-card h2 .dashicons {
    color: #667eea;
    font-size: 1.2em;
}

.barow-card-content {
    padding: 25px;
}

.barow-personalization-form {
    max-width: 1200px;
}

.barow-form-sections {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.barow-form-section {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.barow-form-section h2 {
    margin: 0 0 20px 0;
    display: flex;
    align-items: center;
    gap: 8px;
    color: #1d2327;
    border-bottom: 2px solid #f0f0f1;
    padding-bottom: 10px;
    font-size: 18px;
    font-weight: 600;
}

.barow-form-section h2 .dashicons {
    color: #2271b1;
    font-size: 20px;
    line-height: 1;
}

.barow-form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
}

.barow-form-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 20px;
}

.barow-form-group label {
    font-weight: 600;
    color: #2c3e50;
    font-size: 14px;
    margin-bottom: 5px;
}

.barow-input, .barow-select, .barow-textarea {
    padding: 8px 12px;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    font-size: 14px;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    background: #fff;
    width: 100%;
    box-sizing: border-box;
}

.barow-input:focus, .barow-select:focus, .barow-textarea:focus {
    border-color: #2271b1;
    box-shadow: 0 0 0 1px #2271b1;
    outline: 2px solid transparent;
}

.barow-color-input {
    display: flex;
    align-items: center;
    gap: 10px;
}

.barow-color-picker {
    width: 40px;
    height: 32px;
    padding: 0;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    cursor: pointer;
    background: none;
}

.barow-color-preview {
    width: 32px;
    height: 32px;
    border-radius: 4px;
    border: 1px solid #c3c4c7;
    display: inline-block;
}

.barow-color-text {
    padding: 4px 8px;
    border: 1px solid #c3c4c7;
    border-radius: 4px;
    font-size: 12px;
    font-family: monospace;
    text-transform: uppercase;
    width: 80px;
}

.barow-range-input {
    display: flex;
    align-items: center;
    gap: 10px;
}

.barow-range-input input[type="range"] {
    flex: 1;
}

.barow-range-value {
    font-weight: 600;
    color: #2271b1;
    min-width: 50px;
    text-align: center;
    background: #f6f7f7;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
}

.description {
    font-size: 12px;
    color: #646970;
    font-style: italic;
    margin: 0;
    line-height: 1.4;
}

.barow-form-actions {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 8px;
    padding: 20px;
    display: flex;
    gap: 12px;
    align-items: center;
    margin-top: 20px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.button-large {
    padding: 8px 16px;
    font-size: 14px;
    line-height: 1.5;
    border-radius: 4px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
    border: 1px solid;
    cursor: pointer;
}

.button-large .dashicons {
    font-size: 16px;
    line-height: 1;
}

.barow-preview-container {
    background: #f6f7f7;
    padding: 16px;
    border-radius: 6px;
    border: 1px solid #c3c4c7;
}

.barow-preview-form {
    background: white;
    padding: 20px;
    border-radius: 6px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    border: 2px solid #3498db;
    max-width: 400px;
    margin: 0 auto;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

.barow-preview-form h3 {
    margin: 0 0 20px 0;
    text-align: center;
    color: #333333;
}

.barow-preview-form label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #333333;
    font-size: 14px;
}

.barow-preview-form input {
    width: 100%;
    padding: 10px;
    border: 2px solid #3498db;
    border-radius: 5px;
    margin-bottom: 15px;
    background: #ffffff;
    color: #333333;
    box-sizing: border-box;
}

.barow-preview-form button {
    width: 100%;
    padding: 12px;
    background: #3498db;
    color: #ffffff;
    border: none;
    border-radius: 5px;
    font-weight: 600;
    cursor: pointer;
}

.barow-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white !important;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 14px;
    text-decoration: none;
    transition: all 0.3s ease;
    box-shadow: 0 2px 4px rgba(102, 126, 234, 0.2);
}

.barow-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
    color: white !important;
}

.barow-btn .dashicons {
    font-size: 16px;
    line-height: 1;
}

.barow-btn-secondary {
    background: linear-gradient(135deg, #6c757d 0%, #495057 100%) !important;
    box-shadow: 0 2px 4px rgba(108, 117, 125, 0.2) !important;
}

.barow-btn-secondary:hover {
    box-shadow: 0 6px 20px rgba(108, 117, 125, 0.4) !important;
}

.barow-actions-container {
    background: #fff;
    border: 1px solid #c3c4c7;
    border-radius: 12px;
    padding: 25px;
    margin-top: 25px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
}

.barow-actions-grid {
    display: grid;
    grid-template-columns: 1fr auto;
    gap: 20px;
    align-items: center;
}

.barow-actions-buttons {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.barow-actions-info {
    color: #646970;
    font-size: 14px;
    line-height: 1.5;
}

.barow-actions-info strong {
    color: #1d2327;
    display: block;
    margin-bottom: 4px;
}

@media (max-width: 782px) {
    .barow-actions-grid {
        grid-template-columns: 1fr;
        text-align: center;
    }
    
    .barow-actions-buttons {
        justify-content: center;
    }
    .barow-form-grid {
        grid-template-columns: 1fr;
    }
    
    .barow-form-actions {
        flex-direction: column;
        align-items: stretch;
    }
    
    .barow-form-actions .button {
        text-align: center;
        justify-content: center;
    }
}
</style>

<div class="barow-admin">
    <div class="barow-admin-header">
        <h1>
            <span class="dashicons dashicons-admin-appearance"></span>
            Personalización del Formulario
        </h1>
        <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 16px;">Personaliza la apariencia visual del formulario de reservas. Los cambios se aplicarán automáticamente usando el shortcode <code>[barow_formulario]</code></p>
    </div>

    <form method="post" class="barow-personalization-form">
        <?php wp_nonce_field('barow_personalization_nonce'); ?>
        
        <div class="barow-sections-grid">
            <!-- Texto del Formulario -->
            <div class="barow-section-card">
                <h2>
                    <span class="dashicons dashicons-edit"></span>
                    Textos del Formulario
                </h2>
                <div class="barow-card-content">
                    <div class="barow-form-group">
                        <label for="titulo_formulario">Título del Formulario</label>
                        <input type="text" id="titulo_formulario" name="titulo_formulario" 
                               value="<?php echo esc_attr($titulo_formulario); ?>" class="barow-input">
                        <p class="description">Título que aparece en la parte superior del formulario.</p>
                    </div>
                    <div class="barow-form-group">
                        <label for="texto_boton">Texto del Botón</label>
                        <input type="text" id="texto_boton" name="texto_boton" 
                               value="<?php echo esc_attr($texto_boton); ?>" class="barow-input">
                        <p class="description">Texto que aparece en el botón de envío.</p>
                    </div>
                </div>
            </div>

            <!-- Colores Principales -->
            <div class="barow-section-card">
                <h2>
                    <span class="dashicons dashicons-art"></span>
                    Colores Principales
                </h2>
                <div class="barow-card-content">
                    <div class="barow-form-group">
                        <label for="bg_color">Color del Botón</label>
                        <div class="barow-color-input">
                            <input type="color" id="bg_color" name="bg_color" 
                                   value="<?php echo esc_attr($bg_color); ?>" class="barow-color-picker">
                            <span class="barow-color-preview" style="background-color: <?php echo esc_attr($bg_color); ?>"></span>
                            <input type="text" class="barow-color-text" value="<?php echo esc_attr($bg_color); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="barow-form-group">
                        <label for="borde_color">Color de Bordes</label>
                        <div class="barow-color-input">
                            <input type="color" id="borde_color" name="borde_color" 
                                   value="<?php echo esc_attr($borde_color); ?>" class="barow-color-picker">
                            <span class="barow-color-preview" style="background-color: <?php echo esc_attr($borde_color); ?>"></span>
                            <input type="text" class="barow-color-text" value="<?php echo esc_attr($borde_color); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="barow-form-group">
                        <label for="form_bg_color">Color de Fondo del Formulario</label>
                        <div class="barow-color-input">
                            <input type="color" id="form_bg_color" name="form_bg_color" 
                                   value="<?php echo esc_attr($form_bg_color); ?>" class="barow-color-picker">
                            <span class="barow-color-preview" style="background-color: <?php echo esc_attr($form_bg_color); ?>"></span>
                            <input type="text" class="barow-color-text" value="<?php echo esc_attr($form_bg_color); ?>" readonly>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Colores de Texto -->
            <div class="barow-section-card">
                <h2>
                    <span class="dashicons dashicons-editor-textcolor"></span>
                    Colores de Texto
                </h2>
                <div class="barow-card-content">
                    <div class="barow-form-group">
                        <label for="btn_font_color">Color del Texto del Botón</label>
                        <div class="barow-color-input">
                            <input type="color" id="btn_font_color" name="btn_font_color" 
                                   value="<?php echo esc_attr($btn_font_color); ?>" class="barow-color-picker">
                            <span class="barow-color-preview" style="background-color: <?php echo esc_attr($btn_font_color); ?>"></span>
                            <input type="text" class="barow-color-text" value="<?php echo esc_attr($btn_font_color); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="barow-form-group">
                        <label for="label_font_color">Color de Etiquetas</label>
                        <div class="barow-color-input">
                            <input type="color" id="label_font_color" name="label_font_color" 
                                   value="<?php echo esc_attr($label_font_color); ?>" class="barow-color-picker">
                            <span class="barow-color-preview" style="background-color: <?php echo esc_attr($label_font_color); ?>"></span>
                            <input type="text" class="barow-color-text" value="<?php echo esc_attr($label_font_color); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="barow-form-group">
                        <label for="input_text_color">Color del Texto de Campos</label>
                        <div class="barow-color-input">
                            <input type="color" id="input_text_color" name="input_text_color" 
                                   value="<?php echo esc_attr($input_text_color); ?>" class="barow-color-picker">
                            <span class="barow-color-preview" style="background-color: <?php echo esc_attr($input_text_color); ?>"></span>
                            <input type="text" class="barow-color-text" value="<?php echo esc_attr($input_text_color); ?>" readonly>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Colores de Campos -->
            <div class="barow-section-card">
                <h2>
                    <span class="dashicons dashicons-feedback"></span>
                    Colores de Campos
                </h2>
                <div class="barow-card-content">
                    <div class="barow-form-group">
                        <label for="input_bg_color">Color de Fondo de Campos</label>
                        <div class="barow-color-input">
                            <input type="color" id="input_bg_color" name="input_bg_color" 
                                   value="<?php echo esc_attr($input_bg_color); ?>" class="barow-color-picker">
                            <span class="barow-color-preview" style="background-color: <?php echo esc_attr($input_bg_color); ?>"></span>
                            <input type="text" class="barow-color-text" value="<?php echo esc_attr($input_bg_color); ?>" readonly>
                        </div>
                    </div>
                    
                    <div class="barow-form-group">
                        <label for="borde_radius">Radio de Bordes</label>
                        <div class="barow-range-input">
                            <input type="range" id="borde_radius" name="borde_radius" 
                                   value="<?php echo esc_attr($borde_radius); ?>" min="0" max="25" step="1">
                            <span class="barow-range-value" id="radius_value"><?php echo esc_attr($borde_radius); ?>px</span>
                        </div>
                        <div style="margin-top: 10px;">
                            <div style="width: 50px; height: 50px; background: <?php echo esc_attr($bg_color); ?>; border-radius: <?php echo esc_attr($borde_radius); ?>px; border: 2px solid <?php echo esc_attr($borde_color); ?>;" id="radius_preview"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Vista Previa -->
            <div class="barow-section-card">
                <h2>
                    <span class="dashicons dashicons-visibility"></span>
                    Vista Previa del Formulario
                </h2>
                <div class="barow-card-content">
                <div class="barow-preview-container">
                    <div class="barow-preview-form" id="preview_form">
                        <h3 style="color: <?php echo esc_attr($label_font_color); ?>; margin-top: 0;"><?php echo esc_html($titulo_formulario); ?></h3>
                        <label style="color: <?php echo esc_attr($label_font_color); ?>;">Nombre:</label>
                        <input type="text" placeholder="Tu nombre" style="background: <?php echo esc_attr($input_bg_color); ?>; color: <?php echo esc_attr($input_text_color); ?>; border-color: <?php echo esc_attr($borde_color); ?>; border-radius: <?php echo esc_attr($borde_radius); ?>px;">
                        <label style="color: <?php echo esc_attr($label_font_color); ?>;">Email:</label>
                        <input type="email" placeholder="tu@email.com" style="background: <?php echo esc_attr($input_bg_color); ?>; color: <?php echo esc_attr($input_text_color); ?>; border-color: <?php echo esc_attr($borde_color); ?>; border-radius: <?php echo esc_attr($borde_radius); ?>px;">
                        <button type="button" style="background: <?php echo esc_attr($bg_color); ?>; color: <?php echo esc_attr($btn_font_color); ?>; border-radius: <?php echo esc_attr($borde_radius); ?>px;"><?php echo esc_html($texto_boton); ?></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="barow-actions-container">
            <div class="barow-actions-grid">
                <div class="barow-actions-info">
                    <strong>💡 Información</strong>
                    Los cambios se aplicarán inmediatamente en tu formulario de reservas. Puedes previsualizar los cambios en la sección anterior antes de guardar.
                </div>
                <div class="barow-actions-buttons">
                    <button type="submit" name="barow_save_personalization" class="barow-btn">
                        <span class="dashicons dashicons-saved"></span>
                        Guardar Personalización
                    </button>
                    <button type="button" class="barow-btn barow-btn-secondary" onclick="resetearColores()">
                        <span class="dashicons dashicons-image-rotate"></span>
                        Restablecer Colores
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    // Actualizar vista previa en tiempo real
    function actualizarVistaPreviaFormulario() {
        var bg_color = $('#bg_color').val();
        var btn_font_color = $('#btn_font_color').val();
        var form_bg_color = $('#form_bg_color').val();
        var label_font_color = $('#label_font_color').val();
        var input_bg_color = $('#input_bg_color').val();
        var input_text_color = $('#input_text_color').val();
        var borde_color = $('#borde_color').val();
        var borde_radius = $('#borde_radius').val();
        var titulo_formulario = $('#titulo_formulario').val();
        var texto_boton = $('#texto_boton').val();

        // Actualizar el formulario de vista previa
        $('#preview_form').css({
            'background-color': form_bg_color,
            'border-radius': borde_radius + 'px',
            'border-color': borde_color
        });

        $('#preview_form h3').text(titulo_formulario).css('color', label_font_color);
        $('#preview_form label').css('color', label_font_color);
        $('#preview_form input').css({
            'border-color': borde_color,
            'border-radius': borde_radius + 'px',
            'background-color': input_bg_color,
            'color': input_text_color
        });
        $('#preview_form button').css({
            'background-color': bg_color,
            'color': btn_font_color,
            'border-radius': borde_radius + 'px'
        }).text(texto_boton);

        // Actualizar preview del radio
        $('#radius_preview').css({
            'border-radius': borde_radius + 'px',
            'background': bg_color,
            'border-color': borde_color
        });
    }

    // Evento para actualizar colores en inputs de color
    $('.barow-color-picker').on('input change', function() {
        var color = $(this).val();
        $(this).siblings('.barow-color-text').val(color);
        $(this).siblings('.barow-color-preview').css('background-color', color);
        actualizarVistaPreviaFormulario();
    });

    // Evento para el slider de radio
    $('#borde_radius').on('input', function() {
        var value = $(this).val();
        $('#radius_value').text(value + 'px');
        actualizarVistaPreviaFormulario();
    });

    // Eventos para campos de texto
    $('#titulo_formulario, #texto_boton').on('input', function() {
        actualizarVistaPreviaFormulario();
    });
});

// Función para resetear colores
function resetearColores() {
    if (confirm('¿Estás seguro de que quieres restablecer todos los colores a los valores por defecto?')) {
        document.getElementById('bg_color').value = '#3498db';
        document.getElementById('btn_font_color').value = '#ffffff';
        document.getElementById('form_bg_color').value = '#ffffff';
        document.getElementById('label_font_color').value = '#333333';
        document.getElementById('input_bg_color').value = '#ffffff';
        document.getElementById('input_text_color').value = '#333333';
        document.getElementById('borde_color').value = '#3498db';
        document.getElementById('borde_radius').value = '5';
        document.getElementById('titulo_formulario').value = 'Reserva tu Mesa';
        document.getElementById('texto_boton').value = 'Reservar Ahora';
        
        // Actualizar textos de color y vista previa
        jQuery('.barow-color-picker').trigger('change');
        jQuery('#borde_radius').trigger('input');
    }
}
</script>
