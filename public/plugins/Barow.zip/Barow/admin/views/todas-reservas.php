<?php
if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'reservas';

// Actualizar estados automáticamente
$wpdb->query("UPDATE $table_name SET estado = 'pasada' WHERE fecha_reserva < CURDATE() AND estado IN ('activa', 'confirmada', 'pendiente')");

// Paginación
$reservas_por_pagina = 20;
$pagina_actual = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($pagina_actual - 1) * $reservas_por_pagina;

// Filtros
$filtro_estado = isset($_GET['estado']) ? sanitize_text_field($_GET['estado']) : '';
$filtro_fecha = isset($_GET['fecha']) ? sanitize_text_field($_GET['fecha']) : '';
$buscar = isset($_GET['buscar']) ? sanitize_text_field($_GET['buscar']) : '';

// Construir consulta
$where_clauses = array();
$where_params = array();

if (!empty($filtro_estado)) {
    $where_clauses[] = "estado = %s";
    $where_params[] = $filtro_estado;
}

if (!empty($filtro_fecha)) {
    $where_clauses[] = "fecha_reserva = %s";
    $where_params[] = $filtro_fecha;
}

if (!empty($buscar)) {
    $where_clauses[] = "(nombre_cliente LIKE %s OR email_cliente LIKE %s OR telefono_cliente LIKE %s)";
    $where_params[] = '%' . $buscar . '%';
    $where_params[] = '%' . $buscar . '%';
    $where_params[] = '%' . $buscar . '%';
}

$where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

// Contar total de reservas
$total_query = "SELECT COUNT(*) FROM $table_name $where_sql";
if (!empty($where_params)) {
    $total_reservas = $wpdb->get_var($wpdb->prepare($total_query, $where_params));
} else {
    $total_reservas = $wpdb->get_var($total_query);
}

$total_paginas = ceil($total_reservas / $reservas_por_pagina);

// Obtener reservas
$query = "SELECT * FROM $table_name $where_sql ORDER BY fecha_reserva DESC, hora_reserva DESC LIMIT %d OFFSET %d";
$final_params = array_merge($where_params, array($reservas_por_pagina, $offset));
$reservas = $wpdb->get_results($wpdb->prepare($query, $final_params));

// Obtener reservas de hoy para el botón copiar
$reservas_hoy = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM $table_name WHERE fecha_reserva = %s ORDER BY hora_reserva ASC",
    date('Y-m-d')
));

// Manejar acciones
if (isset($_POST['action']) && isset($_POST['reserva_id'])) {
    $reserva_id = intval($_POST['reserva_id']);
    $action = sanitize_text_field($_POST['action']);
    
    if ($action === 'cancelar') {
        $wpdb->update($table_name, array('estado' => 'cancelada'), array('id' => $reserva_id));
        echo '<div class="notice notice-success"><p>Reserva cancelada exitosamente.</p></div>';
    } elseif ($action === 'eliminar') {
        $wpdb->delete($table_name, array('id' => $reserva_id));
        echo '<div class="notice notice-success"><p>Reserva eliminada exitosamente.</p></div>';
    } elseif ($action === 'editar') {
        $datos_actualizacion = array(
            'nombre_cliente' => sanitize_text_field($_POST['nombre_cliente']),
            'email_cliente' => sanitize_email($_POST['email_cliente']),
            'telefono_cliente' => sanitize_text_field($_POST['telefono_cliente']),
            'fecha_reserva' => sanitize_text_field($_POST['fecha_reserva']),
            'hora_reserva' => sanitize_text_field($_POST['hora_reserva']),
            'cantidad_personas' => intval($_POST['cantidad_personas']),
            'estado' => sanitize_text_field($_POST['estado'])
        );
        
        $resultado = $wpdb->update($table_name, $datos_actualizacion, array('id' => $reserva_id));
        
        if ($resultado !== false) {
            echo '<div class="notice notice-success"><p>Reserva actualizada exitosamente.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error al actualizar la reserva.</p></div>';
        }
    }
    
    // Recargar página para mostrar cambios
    echo '<script>window.location.reload();</script>';
}

// Función para obtener el día de la semana en español
function obtener_dia_semana($fecha) {
    $dias = array('Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado');
    return $dias[date('w', strtotime($fecha))];
}

// Función para obtener el color del día
function obtener_color_dia($fecha) {
    $colores_dias = array(
        0 => '#e74c3c', // Domingo - Rojo
        1 => '#3498db', // Lunes - Azul
        2 => '#2ecc71', // Martes - Verde
        3 => '#f39c12', // Miércoles - Naranja
        4 => '#9b59b6', // Jueves - Morado
        5 => '#1abc9c', // Viernes - Turquesa
        6 => '#e67e22'  // Sábado - Naranja oscuro
    );
    return $colores_dias[date('w', strtotime($fecha))];
}
?>

<div class="barow-admin">
    <div class="barow-admin-header">
        <h1>
            <span class="dashicons dashicons-list-view"></span>
            Todas las Reservas
        </h1>
        <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 16px;">Gestiona todas las reservas de tu restaurante desde este panel central</p>
    </div>

    <!-- Cards de estadísticas del día -->
    <div class="barow-stats-grid">
        <div class="barow-stat-card">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-calendar-alt"></span>
                <h3 class="barow-stat-title">Reservas Hoy</h3>
            </div>
            <div class="barow-stat-value"><?php echo count($reservas_hoy); ?></div>
            <p class="barow-stat-subtitle"><?php echo obtener_dia_semana(date('Y-m-d')) . ', ' . date('j \\d\\e F'); ?></p>
            <button type="button" class="barow-copy-today barow-export-today" title="Copiar todas las reservas de hoy">
                <span class="dashicons dashicons-clipboard"></span>
                Copiar Todas
            </button>
        </div>
        
        <div class="barow-stat-card success">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-clock"></span>
                <h3 class="barow-stat-title">Próxima Reserva</h3>
            </div>
            <?php if (!empty($reservas_hoy)): ?>
                <div class="barow-stat-value"><?php echo date('H:i', strtotime($reservas_hoy[0]->hora_reserva)); ?></div>
                <p class="barow-stat-subtitle"><?php echo esc_html($reservas_hoy[0]->nombre_cliente); ?></p>
            <?php else: ?>
                <div class="barow-stat-value">--:--</div>
                <p class="barow-stat-subtitle">No hay reservas programadas</p>
            <?php endif; ?>
        </div>
        
        <div class="barow-stat-card warning">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-groups"></span>
                <h3 class="barow-stat-title">Personas Hoy</h3>
            </div>
            <div class="barow-stat-value"><?php echo array_sum(array_column($reservas_hoy, 'cantidad_personas')); ?></div>
            <p class="barow-stat-subtitle">Total esperado</p>
        </div>
        
        <div class="barow-stat-card error">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-list-view"></span>
                <h3 class="barow-stat-title">Total Filtradas</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($total_reservas); ?></div>
            <p class="barow-stat-subtitle">En la tabla actual</p>
        </div>
    </div>

    <!-- Card de filtros -->
    <div class="barow-filters-card">
        <div class="barow-card-header">
            <h3>
                <span class="dashicons dashicons-filter"></span>
                Filtros de Búsqueda
            </h3>
        </div>
        
        <div class="barow-card-content">
            <form method="get" class="barow-filter-form-grid">
                <input type="hidden" name="page" value="reserva-mesas">
                
                <div class="barow-filter-group">
                    <label for="buscar">Buscar Cliente</label>
                    <input type="text" id="buscar" name="buscar" value="<?php echo esc_attr($buscar); ?>" 
                           placeholder="Nombre, email o teléfono..." class="barow-filter-input">
                </div>
                
                <div class="barow-filter-group">
                    <label for="estado">Estado</label>
                    <select id="estado" name="estado" class="barow-filter-select">
                        <option value="">Todos los estados</option>
                        <option value="activa" <?php selected($filtro_estado, 'activa'); ?>>Activa</option>
                        <option value="cancelada" <?php selected($filtro_estado, 'cancelada'); ?>>Cancelada</option>
                        <option value="pasada" <?php selected($filtro_estado, 'pasada'); ?>>Pasada</option>
                    </select>
                </div>
                
                <div class="barow-filter-group">
                    <label for="fecha">Fecha Específica</label>
                    <input type="date" id="fecha" name="fecha" value="<?php echo esc_attr($filtro_fecha); ?>" 
                           class="barow-filter-input">
                </div>
                
                <div class="barow-filter-actions">
                    <button type="submit" class="barow-filter-btn primary">
                        <span class="dashicons dashicons-search"></span>
                        Buscar
                    </button>
                    
                    <?php if (!empty($filtro_estado) || !empty($filtro_fecha) || !empty($buscar)): ?>
                        <a href="<?php echo admin_url('admin.php?page=reserva-mesas'); ?>" 
                           class="barow-filter-btn secondary">
                            <span class="dashicons dashicons-no-alt"></span>
                            Limpiar
                        </a>
                    <?php endif; ?>
                    
                    <button type="button" class="barow-filter-btn secondary" onclick="window.location.reload();">
                        <span class="dashicons dashicons-update"></span>
                        Actualizar
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabla de reservas -->
    <div class="barow-table-container">
        <div class="barow-table-header">
            <h3 class="barow-table-title">
                <span class="dashicons dashicons-list-view"></span>
                Lista de Reservas
            </h3>
        </div>
        <?php if (!empty($reservas)): ?>
            <table class="barow-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Contacto</th>
                        <th>Fecha, Día & Hora</th>
                        <th>Personas</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reservas as $reserva): ?>
                        <tr class="barow-reserva-row" data-estado="<?php echo esc_attr($reserva->estado); ?>" data-fecha="<?php echo esc_attr($reserva->fecha_reserva); ?>" data-reserva-id="<?php echo $reserva->id; ?>" style="border-left: 4px solid <?php echo obtener_color_dia($reserva->fecha_reserva); ?>;">
                            <td>
                                <div class="barow-reserva-id">
                                    <?php if ($reserva->estado !== 'pasada'): ?>
                                        <span class="barow-nuevo-label" data-reserva-id="<?php echo $reserva->id; ?>">Nuevo</span>
                                    <?php endif; ?>
                                    <strong>#<?php echo $reserva->id; ?></strong>
                                </div>
                            </td>
                            <td>
                                <div class="barow-client-info">
                                    <strong><?php echo esc_html($reserva->nombre_cliente); ?></strong>
                                </div>
                            </td>
                            <td>
                                <div class="barow-contact-info">
                                    <div><span class="dashicons dashicons-email"></span> <?php echo esc_html($reserva->email_cliente); ?></div>
                                    <div><span class="dashicons dashicons-phone"></span> <?php echo esc_html($reserva->telefono_cliente); ?></div>
                                </div>
                            </td>
                            <td>
                                <div class="barow-datetime">
                                    <div class="barow-date">
                                        <span class="dashicons dashicons-calendar-alt"></span>
                                        <?php echo date('d/m/Y', strtotime($reserva->fecha_reserva)); ?>
                                    </div>
                                    <div class="barow-day" style="color: <?php echo obtener_color_dia($reserva->fecha_reserva); ?>; font-weight: bold;">
                                        <span class="dashicons dashicons-calendar" style="color: <?php echo obtener_color_dia($reserva->fecha_reserva); ?>;"></span>
                                        <?php echo obtener_dia_semana($reserva->fecha_reserva); ?>
                                    </div>
                                    <div class="barow-time">
                                        <span class="dashicons dashicons-clock"></span>
                                        <?php echo esc_html($reserva->hora_reserva); ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="barow-badge barow-badge-people">
                                    <span class="dashicons dashicons-groups"></span>
                                    <?php echo $reserva->cantidad_personas; ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                $estado_class = '';
                                $estado_text = '';
                                $estado_icon = '';
                                switch ($reserva->estado) {
                                    case 'activa':
                                    case 'confirmada':
                                    case 'pendiente':
                                        $estado_class = 'barow-status-active';
                                        $estado_text = 'Activa';
                                        $estado_icon = 'yes-alt';
                                        break;
                                    case 'cancelada':
                                        $estado_class = 'barow-status-cancelled';
                                        $estado_text = 'Cancelada';
                                        $estado_icon = 'dismiss';
                                        break;
                                    case 'pasada':
                                        $estado_class = 'barow-status-past';
                                        $estado_text = 'Pasada';
                                        $estado_icon = 'calendar-alt';
                                        break;
                                    default:
                                        $estado_class = 'barow-status-active';
                                        $estado_text = 'Activa';
                                        $estado_icon = 'yes-alt';
                                }
                                ?>
                                <span class="barow-status <?php echo $estado_class; ?>">
                                    <span class="dashicons dashicons-<?php echo $estado_icon; ?>"></span>
                                    <?php echo $estado_text; ?>
                                </span>
                            </td>
                            <td>
                                <div class="barow-actions">
                                   <!-- Botón de copiado individual -->
                                   <button type="button" class="barow-action-btn barow-btn-copy" title="Copiar reserva"
                                       data-detalle="<?php echo esc_attr(obtener_dia_semana($reserva->fecha_reserva) . ' ' . date('d/m', strtotime($reserva->fecha_reserva)) . ' - ' . $reserva->nombre_cliente . ' - ' . $reserva->hora_reserva . ' - ' . $reserva->cantidad_personas . ' pax - ' . $reserva->telefono_cliente); ?>">
                                       <span class="dashicons dashicons-clipboard"></span>
                                   </button>
                                   
                                   <!-- Botón de editar -->
                                   <button type="button" class="barow-action-btn barow-btn-edit" title="Editar reserva"
                                       data-reserva-id="<?php echo $reserva->id; ?>"
                                       data-nombre="<?php echo esc_attr($reserva->nombre_cliente); ?>"
                                       data-email="<?php echo esc_attr($reserva->email_cliente); ?>"
                                       data-telefono="<?php echo esc_attr($reserva->telefono_cliente); ?>"
                                       data-fecha="<?php echo esc_attr($reserva->fecha_reserva); ?>"
                                       data-hora="<?php echo esc_attr($reserva->hora_reserva); ?>"
                                       data-personas="<?php echo esc_attr($reserva->cantidad_personas); ?>"
                                       data-estado="<?php echo esc_attr($reserva->estado); ?>">
                                       <span class="dashicons dashicons-edit"></span>
                                   </button>
                                    
                                    <?php if ($reserva->estado !== 'cancelada'): ?>
                                        <form method="post" style="display: inline;" 
                                              onsubmit="return confirm('¿Cancelar esta reserva?');">
                                            <input type="hidden" name="action" value="cancelar">
                                            <input type="hidden" name="reserva_id" value="<?php echo $reserva->id; ?>">
                                            <button type="submit" class="barow-action-btn barow-btn-cancel" title="Cancelar">
                                                <span class="dashicons dashicons-no"></span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <form method="post" style="display: inline;" 
                                          onsubmit="return confirm('¿Eliminar esta reserva permanentemente?');">
                                        <input type="hidden" name="action" value="eliminar">
                                        <input type="hidden" name="reserva_id" value="<?php echo $reserva->id; ?>">
                                        <button type="submit" class="barow-action-btn barow-btn-delete" title="Eliminar">
                                            <span class="dashicons dashicons-trash"></span>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="barow-no-results">
                <div class="barow-no-results-icon">
                    <span class="dashicons dashicons-search"></span>
                </div>
                <h3>No se encontraron reservas</h3>
                <p>Intenta ajustar los filtros de búsqueda o verifica que existan reservas en el sistema.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Paginación -->
    <?php if ($total_paginas > 1): ?>
        <div class="barow-pagination">
            <?php
            $base_url = admin_url('admin.php?page=' . $_GET['page']);
            $query_args = array();
            
            if (!empty($filtro_estado)) $query_args['estado'] = $filtro_estado;
            if (!empty($filtro_fecha)) $query_args['fecha'] = $filtro_fecha;
            if (!empty($buscar)) $query_args['buscar'] = $buscar;
            
            if ($pagina_actual > 1): ?>
                <a href="<?php echo add_query_arg(array_merge($query_args, array('paged' => $pagina_actual - 1)), $base_url); ?>" 
                   class="barow-pagination-link">
                    <span class="dashicons dashicons-arrow-left-alt2"></span> Anterior
                </a>
            <?php endif; ?>
            
            <span class="barow-pagination-info">
                Página <?php echo $pagina_actual; ?> de <?php echo $total_paginas; ?>
            </span>
            
            <?php if ($pagina_actual < $total_paginas): ?>
                <a href="<?php echo add_query_arg(array_merge($query_args, array('paged' => $pagina_actual + 1)), $base_url); ?>" 
                   class="barow-pagination-link">
                    Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <!-- Modal de edición -->
        <!-- Modal de Edición -->
    <div id="editarReservaModal" class="edit-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Editar Reserva</h2>
                <span class="modal-close">&times;</span>
            </div>
            <form id="editarReservaForm" method="POST">
                <input type="hidden" name="action" value="editar">
                <input type="hidden" name="reserva_id" id="edit_reserva_id">

                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_nombre_cliente">Nombre Cliente:</label>
                        <input type="text" id="edit_nombre_cliente" name="nombre_cliente" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_email_cliente">Email Cliente:</label>
                        <input type="email" id="edit_email_cliente" name="email_cliente" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_telefono_cliente">Teléfono:</label>
                        <input type="tel" id="edit_telefono_cliente" name="telefono_cliente" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_cantidad_personas">Personas:</label>
                        <input type="number" id="edit_cantidad_personas" name="cantidad_personas" min="1" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_fecha_reserva">Fecha:</label>
                        <input type="date" id="edit_fecha_reserva" name="fecha_reserva" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_hora_reserva">Hora:</label>
                        <input type="time" id="edit_hora_reserva" name="hora_reserva" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="edit_estado_reserva">Estado:</label>
                        <select id="edit_estado_reserva" name="estado" required>
                            <option value="activa">Activa</option>
                            <option value="confirmada">Confirmada</option>
                            <option value="pendiente">Pendiente</option>
                            <option value="cancelada">Cancelada</option>
                            <option value="pasada">Pasada</option>
                        </select>
                    </div>
                </div>

                <div class="bottom-actions">
                    <button type="button" class="button modal-close-button">Cancelar</button>
                    <button type="submit" class="button button-primary">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>

<link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__) . '../../assets/css/admin.css?v=' . time(); ?>">

<style>
/* Estilos específicos solo para todas-reservas - sin duplicar cards ni variables */

/* Panel de control específico para reservas */
.barow-control-panel {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    overflow: hidden;
}

.barow-today-summary {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 20px 25px;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
    color: var(--barow-error);
}

.barow-stat-title {
    margin: 0;
    font-size: 14px;
    font-weight: 600;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.barow-stat-value {
    font-size: 2.5em;
    font-weight: 700;
    color: #2c3e50;
    line-height: 1;
    margin-bottom: 8px;
    text-align: center;
}

.barow-stat-subtitle {
    color: #6c757d;
    font-size: 13px;
    margin: 0 0 15px 0;
    text-align: center;
}

.barow-copy-today {
    background: linear-gradient(135deg, var(--barow-primary) 0%, var(--barow-primary-dark) 100%);
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 6px;
    margin-top: 15px;
    width: 100%;
    justify-content: center;
}

.barow-copy-today:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

/* Card de filtros */
.barow-filters-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    overflow: hidden;
}

.barow-card-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 20px 25px;
    border-bottom: 1px solid #e9ecef;
}

.barow-card-header h3 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #2c3e50;
    font-size: 16px;
    font-weight: 600;
}

.barow-card-header .dashicons {
    color: var(--barow-primary);
    font-size: 18px;
}

.barow-card-content {
    padding: 25px;
}

.barow-filter-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr auto;
    gap: 20px;
    align-items: end;
}

.barow-filter-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.barow-filter-group label {
    font-weight: 600;
    color: #495057;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.barow-filter-input,
.barow-filter-select {
    padding: 12px 16px;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.2s ease;
    background: white;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.barow-filter-input:focus,
.barow-filter-select:focus {
    outline: none;
    border-color: var(--barow-primary);
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.barow-filter-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.barow-filter-btn {
    padding: 12px 20px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    min-width: 100px;
    justify-content: center;
}

.barow-filter-btn.primary {
    background: linear-gradient(135deg, var(--barow-primary) 0%, var(--barow-primary-dark) 100%);
    color: white;
}

.barow-filter-btn.primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.barow-filter-btn.secondary {
    background: #6c757d;
    color: white;
}

.barow-filter-btn.secondary:hover {
    background: #5a6268;
    transform: translateY(-1px);
}

/* Responsive */
@media (max-width: 768px) {
    .barow-admin {
        padding: 15px;
    }
    
    .barow-stats-grid {
        grid-template-columns: 1fr;
    }
    
    .barow-filter-form-grid {
        grid-template-columns: 1fr;
        gap: 15px;
    }
    
    .barow-filter-actions {
        flex-direction: column;
        width: 100%;
    }
    
    .barow-filter-btn {
        width: 100%;
    }
    
    .barow-copy-today {
        margin-top: 15px;
        width: 100%;
        justify-content: center;
    }
}

@media (max-width: 1024px) {
    .barow-filter-form-grid {
        grid-template-columns: 1fr 1fr;
    }
    
    .barow-filter-actions {
        grid-column: 1 / -1;
        justify-content: center;
    }
}

/* Estilos del Modal de Edición */
.edit-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 99999;
}

.modal-content {
    position: relative;
    background: white;
    width: 90%;
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #e0e0e0;
}

.modal-close {
    cursor: pointer;
    font-size: 24px;
    color: #666;
}

.form-row {
    display: flex;
    gap: 15px;
    margin-bottom: 15px;
}

.form-group {
    flex: 1;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.bottom-actions {
    padding: 15px;
    background: #f8f9fa;
    border-top: 1px solid #e0e0e0;
    margin-top: 20px;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

/* Responsive para el modal */
@media (max-width: 782px) {
    .form-row {
        flex-direction: column;
    }
}

/* Label "Nuevo" para reservas */
.barow-nuevo-label {
    position: absolute;
    top: -8px;
    left: -5px;
    background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
    color: white;
    font-size: 10px;
    font-weight: 700;
    padding: 3px 8px;
    border-radius: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px rgba(231, 76, 60, 0.3);
    z-index: 10;
    animation: pulseNuevo 2s infinite;
    border: 2px solid white;
}

/* No mostrar label "Nuevo" en reservas pasadas */
tr[data-estado="pasada"] .barow-nuevo-label {
    display: none !important;
}

/* Estilo visual diferente para reservas pasadas */
tr[data-estado="pasada"] {
    opacity: 0.6;
    background-color: rgba(108, 117, 125, 0.05) !important;
}

tr[data-estado="pasada"] .barow-reserva-id strong {
    color: #6c757d;
}

@keyframes pulseNuevo {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
}

.barow-reserva-id {
    position: relative;
    display: inline-block;
    transition: all 0.3s ease;
}

.barow-reserva-copiada .barow-nuevo-label {
    display: none;
}

.barow-reserva-copiada {
    opacity: 0.7;
    background: rgba(46, 204, 113, 0.05) !important;
}

/* Pequeño indicador visual cuando se copia */
.barow-copiado-check {
    display: inline-block;
    color: #27ae60;
    font-size: 16px;
    margin-left: 5px;
    animation: fadeInCheck 0.5s ease;
}

@keyframes fadeInCheck {
    0% { opacity: 0; transform: scale(0.5); }
    100% { opacity: 1; transform: scale(1); }
}
</style>

<script>
jQuery(document).ready(function($) {
    
    // Inicializar: ocultar labels de reservas ya copiadas
    inicializarEstadoCopiado();
    
    // Copiar al portapapeles - reserva individual
    $('.barow-action-btn.barow-btn-copy').on('click', function () {
        var detalle = $(this).data('detalle');
        var fila = $(this).closest('tr');
        var reservaId = fila.data('reserva-id');
        
        navigator.clipboard.writeText(detalle).then(function () {
            // Marcar reserva como copiada
            marcarComoCopiada(reservaId, fila);
            mostrarNotificacion('Reserva copiada al portapapeles', 'success');
        }).catch(function (err) {
            console.error('Error al copiar: ', err);
        });
    });
    
    // Copiar todas las reservas de hoy
    $('.barow-export-today').on('click', function(e) {
        e.preventDefault();
        
        var reservasHoy = [];
        var reservasHoyIds = [];
        
        <?php if (!empty($reservas_hoy)): ?>
            <?php foreach ($reservas_hoy as $reserva): ?>
                reservasHoy.push('<?php echo esc_js(obtener_dia_semana($reserva->fecha_reserva) . ' ' . date('d/m', strtotime($reserva->fecha_reserva)) . ' - ' . $reserva->nombre_cliente . ' - ' . $reserva->hora_reserva . ' - ' . $reserva->cantidad_personas . ' pax - ' . $reserva->telefono_cliente); ?>');
                reservasHoyIds.push('<?php echo $reserva->id; ?>');
            <?php endforeach; ?>
        <?php endif; ?>
        
        if (reservasHoy.length > 0) {
            var textoCompleto = reservasHoy.join('\n');
            navigator.clipboard.writeText(textoCompleto).then(function () {
                // Marcar todas las reservas de hoy como copiadas
                reservasHoyIds.forEach(function(id) {
                    var fila = $('tr[data-reserva-id="' + id + '"]');
                    marcarComoCopiada(id, fila);
                });
                
                mostrarNotificacion('¡Todas las reservas de hoy copiadas! (' + reservasHoy.length + ' reservas)', 'success');
            }).catch(function (err) {
                console.error('Error al copiar: ', err);
                alert('Error al copiar las reservas');
            });
        } else {
            mostrarNotificacion('No hay reservas para hoy', 'warning');
        }
    });
    
    // Modal de edición (código existente)
    var modal = $('#editarReservaModal');
    
    $('.barow-btn-edit').on('click', function() {
        var data = $(this).data();
        $('#edit_reserva_id').val(data.reservaId);
        $('#edit_nombre_cliente').val(data.nombre);
        $('#edit_email_cliente').val(data.email);
        $('#edit_telefono_cliente').val(data.telefono);
        $('#edit_fecha_reserva').val(data.fecha);
        $('#edit_hora_reserva').val(data.hora);
        $('#edit_cantidad_personas').val(data.personas);
        $('#edit_estado_reserva').val(data.estado);
        modal.show();
    });
    
    $('.modal-close, .modal-close-button').on('click', function() {
        modal.hide();
    });
    
    $(window).on('click', function(event) {
        if ($(event.target).is(modal)) {
            modal.hide();
        }
    });
    
    // Funciones auxiliares
    function marcarComoCopiada(reservaId, fila) {
        // No marcar como copiada si es una reserva pasada
        var estado = fila.data('estado');
        if (estado === 'pasada') {
            return;
        }
        
        // Agregar a localStorage
        var copiadas = JSON.parse(localStorage.getItem('barow_reservas_copiadas') || '[]');
        if (copiadas.indexOf(reservaId.toString()) === -1) {
            copiadas.push(reservaId.toString());
            localStorage.setItem('barow_reservas_copiadas', JSON.stringify(copiadas));
        }
        
        // Efectos visuales
        fila.addClass('barow-reserva-copiada');
        var nuevoLabel = fila.find('.barow-nuevo-label');
        nuevoLabel.fadeOut(300);
        
        // Agregar check temporal
        var checkIcon = $('<span class="barow-copiado-check dashicons dashicons-yes"></span>');
        fila.find('.barow-reserva-id strong').append(checkIcon);
        setTimeout(function() {
            checkIcon.fadeOut(2000, function() { checkIcon.remove(); });
        }, 2000);
    }
    
    function inicializarEstadoCopiado() {
        var copiadas = JSON.parse(localStorage.getItem('barow_reservas_copiadas') || '[]');
        
        copiadas.forEach(function(reservaId) {
            var fila = $('tr[data-reserva-id="' + reservaId + '"]');
            if (fila.length) {
                // Solo marcar como copiada si NO es una reserva pasada
                var estado = fila.data('estado');
                if (estado !== 'pasada') {
                    fila.addClass('barow-reserva-copiada');
                    fila.find('.barow-nuevo-label').hide();
                }
            }
        });
        
        // Ocultar automáticamente labels de reservas pasadas
        $('tr[data-estado="pasada"] .barow-nuevo-label').hide();
    }
    
    // Limpiar localStorage de reservas antiguas (opcional - más de 7 días)
    function limpiarReservasAntiguas() {
        var copiadas = JSON.parse(localStorage.getItem('barow_reservas_copiadas') || '[]');
        // En una implementación real, podrías filtrar por fecha, pero por simplicidad lo dejamos así
        // localStorage.setItem('barow_reservas_copiadas', JSON.stringify([]));
    }
    
    // Función para mostrar notificaciones
    function mostrarNotificacion(mensaje, tipo) {
        var iconClass = tipo === 'success' ? 'yes' : (tipo === 'warning' ? 'warning' : 'dismiss');
        var notification = $('<div class="barow-notification ' + tipo + '">' +
            '<div class="barow-notification-content">' +
            '<span class="barow-notification-icon dashicons dashicons-' + iconClass + '"></span>' +
            '<span>' + mensaje + '</span>' +
            '</div></div>');
        
        $('body').append(notification);
        
        setTimeout(function() {
            notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 4000);
    }
    
    // Opcional: Botón para limpiar todas las marcas de "copiado"
    $(document).on('keydown', function(e) {
        // Ctrl + Shift + R para resetear (solo para desarrollo/testing)
        if (e.ctrlKey && e.shiftKey && e.keyCode === 82) {
            localStorage.removeItem('barow_reservas_copiadas');
            $('.barow-reserva-copiada').removeClass('barow-reserva-copiada');
            
            // Solo mostrar labels "Nuevo" en reservas que NO sean pasadas
            $('.barow-nuevo-label').each(function() {
                var fila = $(this).closest('tr');
                var estado = fila.data('estado');
                if (estado !== 'pasada') {
                    $(this).show();
                }
            });
            
            mostrarNotificacion('Labels "Nuevo" restaurados (excepto reservas pasadas)', 'success');
        }
    });
});
</script>
