<?php
/**
 * Vista de Clientes para el panel de administración
 * Utiliza la tabla wp_reservas existente
 */

// Verificar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Función para calcular tiempo transcurrido de forma inteligente
function calcular_tiempo_transcurrido($fecha) {
    $ahora = time();
    $fecha_timestamp = strtotime($fecha);
    
    // Si la fecha es futura o hoy pero no ha pasado aún, mostrar "sin visitar"
    if ($fecha_timestamp > $ahora || date('Y-m-d', $fecha_timestamp) > date('Y-m-d', $ahora)) {
        return 'Sin visitar';
    }
    
    $diferencia = $ahora - $fecha_timestamp;
    
    $minutos = $diferencia / 60;
    $horas = $diferencia / 3600;
    $dias = $diferencia / 86400;
    $semanas = $dias / 7;
    $meses = $dias / 30.44; // Promedio de días por mes
    $años = $dias / 365.25; // Promedio de días por año
    
    if ($minutos < 5) {
        return 'Hace unos minutos';
    } elseif ($minutos < 60) {
        return 'Hace ' . round($minutos) . ' min';
    } elseif ($horas < 24) {
        return 'Hace ' . round($horas) . ' h';
    } elseif ($dias < 7) {
        return 'Hace ' . round($dias) . ' días';
    } elseif ($semanas < 4) {
        return 'Hace ' . round($semanas) . ' semanas';
    } elseif ($meses < 12) {
        return 'Hace ' . round($meses) . ' meses';
    } else {
        return 'Hace ' . round($años) . ' años';
    }
}

// Obtener clientes únicos de la tabla existente
global $wpdb;
$table_name = $wpdb->prefix . 'reservas';

// Configuración de paginación
$items_per_page = 30;
$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
$offset = ($current_page - 1) * $items_per_page;

// Filtros
$filtro_frecuencia = isset($_GET['frecuencia']) ? sanitize_text_field($_GET['frecuencia']) : '';
$buscar = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

// Construir WHERE clause para filtros
$where_conditions = array();
$where_params = array();

if (!empty($buscar)) {
    $where_conditions[] = "(nombre_cliente LIKE %s OR email_cliente LIKE %s OR telefono_cliente LIKE %s)";
    $where_params[] = "%$buscar%";
    $where_params[] = "%$buscar%";
    $where_params[] = "%$buscar%";
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Obtener clientes únicos con estadísticas
$clientes_query = "
    SELECT 
        email_cliente as email,
        nombre_cliente as nombre,
        telefono_cliente as telefono,
        COUNT(*) as total_reservas,
        MAX(fecha_reserva) as ultima_reserva,
        MIN(fecha_reserva) as primera_reserva,
        SUM(CASE WHEN estado != 'cancelada' THEN 1 ELSE 0 END) as reservas_confirmadas,
        SUM(cantidad_personas) as total_personas
    FROM $table_name 
    $where_clause
    GROUP BY email_cliente 
";

// Aplicar filtro de frecuencia después del GROUP BY
if ($filtro_frecuencia) {
    switch ($filtro_frecuencia) {
        case 'nuevos':
            $clientes_query .= " HAVING total_reservas = 1";
            break;
        case 'regulares':
            $clientes_query .= " HAVING total_reservas BETWEEN 2 AND 4";
            break;
        case 'frecuentes':
            $clientes_query .= " HAVING total_reservas >= 5";
            break;
    }
}

$clientes_query .= " ORDER BY MAX(fecha_reserva) DESC LIMIT $items_per_page OFFSET $offset";

if (!empty($where_params)) {
    $clientes = $wpdb->get_results($wpdb->prepare($clientes_query, $where_params));
} else {
    $clientes = $wpdb->get_results($clientes_query);
}

// Total de clientes para paginación (considerando filtros)
$count_query = "
    SELECT COUNT(DISTINCT email_cliente) 
    FROM $table_name 
    $where_clause
";

if (!empty($where_params)) {
    $total_clientes = $wpdb->get_var($wpdb->prepare($count_query, $where_params));
} else {
    $total_clientes = $wpdb->get_var($count_query);
}

$total_pages = ceil($total_clientes / $items_per_page);

// Estadísticas generales
$stats = array(
    'total_clientes' => $wpdb->get_var("SELECT COUNT(DISTINCT email_cliente) FROM $table_name"),
    'clientes_nuevos' => $wpdb->get_var("
        SELECT COUNT(*) FROM (
            SELECT email_cliente, COUNT(*) as total 
            FROM $table_name 
            GROUP BY email_cliente 
            HAVING total = 1
        ) as nuevos
    "),
    'clientes_regulares' => $wpdb->get_var("
        SELECT COUNT(*) FROM (
            SELECT email_cliente, COUNT(*) as total 
            FROM $table_name 
            GROUP BY email_cliente 
            HAVING total BETWEEN 2 AND 4
        ) as regulares
    "),
    'clientes_frecuentes' => $wpdb->get_var("
        SELECT COUNT(*) FROM (
            SELECT email_cliente, COUNT(*) as total 
            FROM $table_name 
            GROUP BY email_cliente 
            HAVING total >= 5
        ) as frecuentes
    ")
);
?>

<div class="barow-admin">
    <div class="barow-admin-header">
        <h1>
            <span class="dashicons dashicons-groups"></span>
            Gestión de Clientes
        </h1>
        <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 16px;">Administra y analiza la base de datos de clientes de tu restaurante</p>
    </div>
    
    <!-- Estadísticas de clientes -->
    <div class="barow-stats-grid">
        <div class="barow-stat-card">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-groups"></span>
                <h3 class="barow-stat-title">Total Clientes</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($stats['total_clientes']); ?></div>
            <p class="barow-stat-subtitle">Base de datos completa</p>
        </div>
        
        <div class="barow-stat-card success">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-plus-alt"></span>
                <h3 class="barow-stat-title">Nuevos</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($stats['clientes_nuevos']); ?></div>
            <p class="barow-stat-subtitle">1 reserva únicamente</p>
        </div>
        
        <div class="barow-stat-card warning">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-businessman"></span>
                <h3 class="barow-stat-title">Regulares</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($stats['clientes_regulares']); ?></div>
            <p class="barow-stat-subtitle">2-4 reservas</p>
        </div>
        
        <div class="barow-stat-card error">
            <div class="barow-stat-header">
                <span class="barow-stat-icon dashicons dashicons-star-filled"></span>
                <h3 class="barow-stat-title">Frecuentes</h3>
            </div>
            <div class="barow-stat-value"><?php echo number_format($stats['clientes_frecuentes']); ?></div>
            <p class="barow-stat-subtitle">5+ reservas</p>
        </div>
    </div>
    
    <!-- Card de filtros -->
    <div class="barow-filters-card">
        <div class="barow-card-header">
            <h3>
                <span class="dashicons dashicons-filter"></span>
                Filtros de Búsqueda
            </h3>
        </div>
        
        <div class="barow-card-content">
            <form method="get" class="barow-filter-form-grid">
                <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page']); ?>">
                
                <div class="barow-filter-group">
                    <label for="buscar">Buscar Cliente</label>
                    <input type="text" id="buscar" name="s" value="<?php echo esc_attr($buscar); ?>" 
                           placeholder="Nombre, email o teléfono..." class="barow-filter-input">
                </div>
                
                <div class="barow-filter-group">
                    <label for="frecuencia">Tipo de Cliente</label>
                    <select id="frecuencia" name="frecuencia" class="barow-filter-select">
                        <option value="">Todos los clientes</option>
                        <option value="nuevos" <?php selected($filtro_frecuencia, 'nuevos'); ?>>Nuevos (1 reserva)</option>
                        <option value="regulares" <?php selected($filtro_frecuencia, 'regulares'); ?>>Regulares (2-4 reservas)</option>
                        <option value="frecuentes" <?php selected($filtro_frecuencia, 'frecuentes'); ?>>Frecuentes (5+ reservas)</option>
                    </select>
                </div>
                
                <div class="barow-filter-group">
                    <!-- Espacio para filtros adicionales futuros -->
                </div>
                
                <div class="barow-filter-actions">
                    <button type="submit" class="barow-filter-btn primary">
                        <span class="dashicons dashicons-search"></span>
                        Buscar
                    </button>
                    
                    <?php if (!empty($buscar) || !empty($filtro_frecuencia)): ?>
                        <a href="<?php echo admin_url('admin.php?page=' . $_GET['page']); ?>" 
                           class="barow-filter-btn secondary">
                            <span class="dashicons dashicons-no-alt"></span>
                            Limpiar
                        </a>
                    <?php endif; ?>
                    
                    <button type="button" class="barow-filter-btn secondary" onclick="window.location.reload();">
                        <span class="dashicons dashicons-update"></span>
                        Actualizar
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Tabla de clientes -->
    <div class="barow-table-container">
        <div class="barow-table-header">
            <h3 class="barow-table-title">
                <span class="dashicons dashicons-admin-users"></span>
                Lista de Clientes
            </h3>
        </div>
        <?php if (!empty($clientes)): ?>
            <table class="barow-table">
                <thead>
                    <tr>
                        <th style="width: 35%;">Cliente</th>
                        <th style="width: 30%;">Contacto</th>
                        <th style="width: 20%;">Reservas</th>
                        <th style="width: 15%;">Última Visita</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($clientes as $cliente): ?>
                        <tr class="barow-cliente-row">
                            <td>
                                <div class="barow-client-info">
                                    <strong><?php echo esc_html($cliente->nombre); ?></strong>
                                    <div style="color: #666; font-size: 12px; margin-top: 2px;">
                                        Cliente desde <?php echo date('d/m/Y', strtotime($cliente->primera_reserva)); ?>
                                    </div>
                                    <?php 
                                    // Mostrar badge de tipo de cliente
                                    if ($cliente->total_reservas >= 5) {
                                        echo '<span class="barow-badge barow-badge-frecuente">Frecuente</span>';
                                    } elseif ($cliente->total_reservas >= 2) {
                                        echo '<span class="barow-badge barow-badge-regular">Regular</span>';
                                    } else {
                                        echo '<span class="barow-badge barow-badge-nuevo">Nuevo</span>';
                                    }
                                    ?>
                                </div>
                            </td>
                            <td>
                                <div class="barow-contact-info">
                                    <div>
                                        <span class="dashicons dashicons-email"></span>
                                        <a href="mailto:<?php echo esc_attr($cliente->email); ?>">
                                            <?php echo esc_html($cliente->email); ?>
                                        </a>
                                    </div>
                                    <?php if ($cliente->telefono): ?>
                                    <div>
                                        <span class="dashicons dashicons-phone"></span>
                                        <a href="tel:<?php echo esc_attr($cliente->telefono); ?>">
                                            <?php echo esc_html($cliente->telefono); ?>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="barow-reservas-stats">
                                    <div class="barow-total-reservas">
                                        <span class="dashicons dashicons-calendar-alt"></span>
                                        <?php echo number_format($cliente->total_reservas); ?> total
                                    </div>
                                    <div class="barow-confirmadas">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <?php echo number_format($cliente->reservas_confirmadas); ?> confirmadas
                                    </div>
                                    <div class="barow-personas">
                                        <span class="dashicons dashicons-groups"></span>
                                        <?php echo number_format($cliente->total_personas); ?> personas
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="barow-ultima-visita">
                                    <div class="barow-fecha-visita">
                                        <?php echo date('d/m/Y', strtotime($cliente->ultima_reserva)); ?>
                                    </div>
                                    <div class="barow-tiempo-transcurrido">
                                        <?php echo calcular_tiempo_transcurrido($cliente->ultima_reserva); ?>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="barow-no-results">
                <div class="barow-no-results-icon">
                    <span class="dashicons dashicons-admin-users"></span>
                </div>
                <h3>No se encontraron clientes</h3>
                <p><?php echo !empty($buscar) || !empty($filtro_frecuencia) ? 'Intenta ajustar los filtros de búsqueda.' : 'Los clientes aparecerán aquí cuando realicen su primera reserva.'; ?></p>
                <?php if (!empty($buscar) || !empty($filtro_frecuencia)): ?>
                    <a href="<?php echo admin_url('admin.php?page=' . $_GET['page']); ?>" class="barow-button barow-button-secondary">
                        <span class="dashicons dashicons-clear"></span>
                        Limpiar Filtros
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <!-- Paginación -->
    <?php if ($total_pages > 1): ?>
        <div class="barow-pagination">
            <?php
            $base_url = admin_url('admin.php?page=' . $_GET['page']);
            $query_args = array();
            
            if (!empty($buscar)) $query_args['s'] = $buscar;
            if (!empty($filtro_frecuencia)) $query_args['frecuencia'] = $filtro_frecuencia;
            
            if ($current_page > 1): ?>
                <a href="<?php echo add_query_arg(array_merge($query_args, array('paged' => $current_page - 1)), $base_url); ?>" 
                   class="barow-pagination-link">
                    <span class="dashicons dashicons-arrow-left-alt2"></span> Anterior
                </a>
            <?php endif; ?>
            
            <span class="barow-pagination-info">
                Página <?php echo $current_page; ?> de <?php echo $total_pages; ?>
            </span>
            
            <?php if ($current_page < $total_pages): ?>
                <a href="<?php echo add_query_arg(array_merge($query_args, array('paged' => $current_page + 1)), $base_url); ?>" 
                   class="barow-pagination-link">
                    Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__) . '../../assets/css/admin.css?v=' . time(); ?>">

<style>
/* Estilos específicos solo para clientes - sin duplicar cards ni variables */

/* Card de filtros específica para clientes */
.barow-filters-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    overflow: hidden;
}

.barow-card-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 20px 25px;
    border-bottom: 1px solid #e9ecef;
}

.barow-card-header h3 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #2c3e50;
    font-size: 16px;
    font-weight: 600;
}

.barow-card-header .dashicons {
    color: var(--barow-primary);
    font-size: 18px;
}

.barow-card-content {
    padding: 25px;
}

.barow-filter-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr auto;
    gap: 20px;
    align-items: end;
}

.barow-stat-title {
    margin: 0;
    font-size: 14px;
    font-weight: 600;
    color: #6c757d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.barow-stat-value {
    font-size: 2.5em;
    font-weight: 700;
    color: #2c3e50;
    line-height: 1;
    margin-bottom: 8px;
    text-align: center;
}

.barow-stat-subtitle {
    color: #6c757d;
    font-size: 13px;
    margin: 0;
    text-align: center;
}

/* Card de filtros */
.barow-filters-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    overflow: hidden;
}

.barow-card-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 20px 25px;
    border-bottom: 1px solid #e9ecef;
}

.barow-card-header h3 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    color: #2c3e50;
    font-size: 16px;
    font-weight: 600;
}

.barow-card-header .dashicons {
    color: var(--barow-primary);
    font-size: 18px;
}

.barow-card-content {
    padding: 25px;
}

.barow-filter-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr auto;
    gap: 20px;
    align-items: end;
}

.barow-filter-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.barow-filter-group label {
    font-weight: 600;
    color: #495057;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.barow-filter-input,
.barow-filter-select {
    padding: 12px 16px;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.2s ease;
    background: white;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
}

.barow-filter-input:focus,
.barow-filter-select:focus {
    outline: none;
    border-color: var(--barow-primary);
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.barow-filter-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.barow-filter-btn {
    padding: 12px 20px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    min-width: 100px;
    justify-content: center;
}

.barow-filter-btn.primary {
    background: linear-gradient(135deg, var(--barow-primary) 0%, var(--barow-primary-dark) 100%);
    color: white;
}

.barow-filter-btn.primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.barow-filter-btn.secondary {
    background: #6c757d;
    color: white;
}

.barow-filter-btn.secondary:hover {
    background: #5a6268;
    transform: translateY(-1px);
}

/* Responsive */
@media (max-width: 768px) {
    .barow-admin {
        padding: 15px;
    }
    
    .barow-stats-grid {
        grid-template-columns: 1fr;
    }
    
    .barow-filter-form-grid {
        grid-template-columns: 1fr;
        gap: 15px;
    }
    
    .barow-filter-actions {
        flex-direction: column;
        width: 100%;
    }
    
    .barow-filter-btn {
        width: 100%;
    }
}

@media (max-width: 1024px) {
    .barow-filter-form-grid {
        grid-template-columns: 1fr 1fr;
    }
    
    .barow-filter-actions {
        grid-column: 1 / -1;
        justify-content: center;
    }
}
</style>
